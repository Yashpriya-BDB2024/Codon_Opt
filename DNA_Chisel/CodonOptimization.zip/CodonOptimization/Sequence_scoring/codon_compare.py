# -*- coding: utf-8 -*-
"""
codon_compare.py  --  Compare two DNA sequences on the codon_features panel
===========================================================================

Runs two coding sequences (generic labels ID1 and ID2) through the SAME scorer
as codon_features.py -- it imports compute_features, so there is one definition
of every metric -- then reports per-metric deltas and winners, overlays the
positional profiles, and draws a scorecard.

Reference data is supplied as input files, exactly as in codon_features.py:
--codon-table (CoCoPUTs CSV) and --tgcn (GtRNAdb CSV). Nothing is downloaded.

Outputs (with --out PREFIX)
    PREFIX_comparison.csv      metric | ID1 | ID2 | delta | better | winner
    PREFIX_comparison.json     scalar scores for both plus the comparison table
    PREFIX_overlay_profiles.png ID1 vs ID2 overlaid for the 9 positional profiles
    PREFIX_scorecard.png       sorted delta bars + a win tally

CLI
    python3 codon_compare.py --seq-a ATG... --seq-b ATG... \
        --codon-table cho_codon.csv --tgcn cho_tgcn.csv --host-label CHO \
        --label-a WT --label-b Optimized --out cmp
    # or from a 2-record FASTA:
    python3 codon_compare.py --fasta pair.fasta --host-label human \
        --codon-table human_codon.csv --tgcn human_tgcn.csv --out cmp

Dependencies: codon_features and its deps; pandas, matplotlib for output.
"""

from __future__ import annotations
import argparse
import json
import os

import numpy as np

import codon_features as cf
from codon_features import compute_features, read_fasta

# GC target band per host, used only to pick the winner on band-type metrics.
_GC_BANDS = {"coli": (40.0, 55.0), "human": (40.0, 65.0), "sapiens": (40.0, 65.0),
             "cho": (40.0, 65.0), "gris": (40.0, 65.0)}


def gc_band_for(label):
    low = (label or "").lower()
    for k, band in _GC_BANDS.items():
        if k in low:
            return band
    return (40.0, 65.0)

# Scalar metrics compared, with the direction that counts as "better".
# higher/lower = obvious; band = closer to the host GC band midpoint; na = shown
# but not scored as a win (context-dependent).
COMPARE_METRICS = [
    ("CAI", "higher"), ("rare_codon_pct", "lower"), ("ENC", "na"),
    ("tAI", "higher"), ("tAI_ramp", "na"), ("minmax_mean", "na"),
    ("codon_autocorr_lag1", "na"),
    ("GC_pct", "band"), ("GC_max_60bp", "lower"), ("GC3_pct", "na"),
    ("CpG_density_per100bp", "lower"),
    ("TIS_accessibility_5p", "higher"), ("MFE_min_window", "higher"),
    ("stable_structure_count", "lower"), ("hairpin_count_all", "lower"),
    ("hairpin_count_5prime", "lower"), ("splice_sites_total", "lower"),
    ("homopolymer_runs_ge6", "lower"), ("restriction_sites_total", "lower"),
    ("repeat_count_10bp", "lower"), ("repeat_count_20bp", "lower"),
    ("kozak_score", "higher"), ("tm_spread", "lower"),
]

# Design system (shared with the codon_features figure for a consistent look)
C_A, C_B = "#1565C0", "#E65100"          # ID1 / ID2
GREEN, RED, DRAW = "#2E7D32", "#C62828", "#78909C"


def winner_of(metric, a, b, direction, gc_band):
    if a is None or b is None:
        return "na"
    try:
        a, b = float(a), float(b)
    except (TypeError, ValueError):
        return "na"
    eps = 1e-9
    if direction == "higher":
        return "draw" if abs(a - b) < eps else ("A" if a > b else "B")
    if direction == "lower":
        return "draw" if abs(a - b) < eps else ("A" if a < b else "B")
    if direction == "band":
        mid = (gc_band[0] + gc_band[1]) / 2.0
        da, db = abs(a - mid), abs(b - mid)
        return "draw" if abs(da - db) < eps else ("A" if da < db else "B")
    return "na"


def compare(seq_a, seq_b, label_a, label_b, host="human", host_label=None,
            codon_table=None, tgcn=None, utr5="", **overrides):
    ra = compute_features(seq_a, host=host, host_label=host_label, codon_table=codon_table,
                          tgcn=tgcn, utr5=utr5, name=label_a, **overrides)
    rb = compute_features(seq_b, host=host, host_label=host_label, codon_table=codon_table,
                          tgcn=tgcn, utr5=utr5, name=label_b, **overrides)
    gc_band = gc_band_for(host_label or ra.get("host") or host)
    rows = []
    for metric, direction in COMPARE_METRICS:
        av, bv = ra["scores"].get(metric), rb["scores"].get(metric)
        delta = None
        try:
            delta = round(float(bv) - float(av), 4)
        except (TypeError, ValueError):
            pass
        w = winner_of(metric, av, bv, direction, gc_band)
        rows.append({"metric": metric, label_a: av, label_b: bv, "delta": delta,
                     "better": direction,
                     "winner": {"A": label_a, "B": label_b, "draw": "draw", "na": "-"}[w],
                     "_w": w})
    return ra, rb, rows


# ---------------------------------------------------------------------------
# Plots
# ---------------------------------------------------------------------------
def _init_mpl():
    import matplotlib
    matplotlib.use("Agg")


def overlay_profiles(ra, rb, label_a, label_b, path):
    import matplotlib.pyplot as plt
    A, B = ra["profiles"], rb["profiles"]
    specs = [
        ("GC % (nt window)", A["nt_window"]["gc"], B["nt_window"]["gc"], "nt"),
        ("MFE dG (nt window)", A["mfe_window"], B["mfe_window"], "nt"),
        ("%MinMax (codon)", A["codon_window"]["minmax"], B["codon_window"]["minmax"], "codon"),
        ("Rolling CAI", A["codon_window"]["rolling_cai"], B["codon_window"]["rolling_cai"], "codon"),
        ("Rolling tAI", A["codon_window"]["rolling_tai"], B["codon_window"]["rolling_tai"], "codon"),
        ("Windowed ENC", A["codon_window"]["enc_window"], B["codon_window"]["enc_window"], "codon"),
        ("CpG density /100bp", A["nt_window"]["cpg_density"], B["nt_window"]["cpg_density"], "nt"),
    ]
    specs = [s for s in specs if s[1].get("value") or s[2].get("value")]
    n = len(specs)
    if n == 0:
        return None
    fig, axs = plt.subplots(n, 1, figsize=(11, 2.1 * n))
    if n == 1:
        axs = [axs]
    for ax, (title, pa, pb, xlab) in zip(axs, specs):
        if pa.get("value"):
            ax.plot(pa["index"], pa["value"], color=C_A, lw=1.4, label=label_a)
        if pb.get("value"):
            ax.plot(pb["index"], pb["value"], color=C_B, lw=1.4, label=label_b)
        ax.set_title(title, fontsize=10, loc="left", fontweight="bold")
        ax.set_xlabel(xlab); ax.grid(alpha=0.3); ax.legend(fontsize=8, loc="best")
    fig.suptitle("Positional profiles: {} vs {}".format(label_a, label_b),
                 fontsize=13, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.99])
    fig.savefig(path, dpi=140, bbox_inches="tight"); plt.close(fig)
    return path


def scorecard(rows, label_a, label_b, path):
    import matplotlib.pyplot as plt
    scored = [r for r in rows if r["_w"] in ("A", "B", "draw") and r["delta"] is not None]
    if not scored:
        return None
    a_wins = sum(1 for r in scored if r["_w"] == "A")
    b_wins = sum(1 for r in scored if r["_w"] == "B")
    draws = sum(1 for r in scored if r["_w"] == "draw")
    # delta bars (ID2 - ID1), colored by who the delta favours
    bar = sorted(scored, key=lambda r: abs(r["delta"]))
    names = [r["metric"] for r in bar]
    deltas = [r["delta"] for r in bar]
    cols = [GREEN if r["_w"] == "B" else (RED if r["_w"] == "A" else DRAW) for r in bar]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, max(5, 0.42 * len(names))),
                                   gridspec_kw={"width_ratios": [2.4, 1]})
    y = np.arange(len(names))
    ax1.barh(y, deltas, color=cols, height=0.72)
    ax1.axvline(0, color="#666", lw=1)
    ax1.set_yticks(y); ax1.set_yticklabels(names, fontsize=8.5)
    ax1.set_title("Delta ({} - {}); green = {} better".format(label_b, label_a, label_b),
                  fontsize=12, fontweight="bold")
    ax1.grid(axis="x", alpha=0.3)
    vals = [v for v in [b_wins, a_wins, draws] if v]
    labs, colr = [], []
    if b_wins: labs.append("{} ({})".format(label_b, b_wins)); colr.append(GREEN)
    if a_wins: labs.append("{} ({})".format(label_a, a_wins)); colr.append(RED)
    if draws: labs.append("Draw ({})".format(draws)); colr.append(DRAW)
    ax2.pie(vals, labels=labs, colors=colr, autopct="%1.0f%%", startangle=90,
            textprops={"fontsize": 10}, wedgeprops={"edgecolor": "white", "linewidth": 2})
    ax2.set_title("{} scored metrics".format(len(scored)), fontsize=11, fontweight="bold")
    fig.suptitle("{} vs {} - scorecard".format(label_a, label_b), fontsize=14, fontweight="bold")
    fig.tight_layout()
    fig.savefig(path, dpi=140, bbox_inches="tight"); plt.close(fig)
    return path


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main(argv=None):
    p = argparse.ArgumentParser(description="Compare two sequences on the codon_features panel.")
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--seq-a", dest="seq_a")
    src.add_argument("--fasta", help="2-record FASTA (first two sequences compared)")
    p.add_argument("--seq-b", dest="seq_b")
    p.add_argument("--label-a", dest="label_a", default="ID1")
    p.add_argument("--label-b", dest="label_b", default="ID2")
    p.add_argument("--host", default="human")
    p.add_argument("--host-label", dest="host_label")
    p.add_argument("--codon-table", dest="codon_table", help="codon usage CSV (CoCoPUTs); applied to both")
    p.add_argument("--tgcn", help="GtRNAdb anticodon,count CSV; enables tAI for both")
    p.add_argument("--utr5", default="")
    p.add_argument("--rare-threshold", dest="rare_threshold", type=float, default=cf.DEFAULTS["rare_threshold"])
    p.add_argument("--out", help="output prefix")
    args = p.parse_args(argv)

    if args.seq_a and not args.seq_b:
        p.error("--seq-a requires --seq-b")
    if args.fasta:
        recs = list(read_fasta(args.fasta))
        if len(recs) < 2:
            p.error("FASTA needs at least 2 records")
        la = args.label_a if args.label_a != "ID1" else (recs[0][0] or "ID1")[:16]
        lb = args.label_b if args.label_b != "ID2" else (recs[1][0] or "ID2")[:16]
        seq_a, seq_b = recs[0][1], recs[1][1]
    else:
        la, lb, seq_a, seq_b = args.label_a, args.label_b, args.seq_a, args.seq_b

    ra, rb, rows = compare(seq_a, seq_b, la, lb, host=args.host, host_label=args.host_label,
                           codon_table=args.codon_table, tgcn=args.tgcn, utr5=args.utr5,
                           rare_threshold=args.rare_threshold)

    # console table
    print("=" * 72)
    print("  {}  vs  {}   (host: {})".format(la, lb, ra.get("host")))
    print("=" * 72)
    print("  {:<24} {:>12} {:>12} {:>10}  {}".format("metric", la[:12], lb[:12], "delta", "winner"))
    for r in rows:
        print("  {:<24} {:>12} {:>12} {:>10}  {}".format(
            r["metric"], str(r[la]), str(r[lb]), str(r["delta"]), r["winner"]))
    a_wins = sum(1 for r in rows if r["_w"] == "A")
    b_wins = sum(1 for r in rows if r["_w"] == "B")
    print("-" * 72)
    print("  {} wins: {}   {} wins: {}".format(la, a_wins, lb, b_wins))
    print("=" * 72)

    if args.out:
        import pandas as pd
        df = pd.DataFrame([{k: v for k, v in r.items() if k != "_w"} for r in rows])
        df.to_csv(args.out + "_comparison.csv", index=False)
        with open(args.out + "_comparison.json", "w") as fh:
            json.dump({"label_a": la, "label_b": lb, "host": ra.get("host"),
                       "scores_a": ra["scores"], "scores_b": rb["scores"],
                       "comparison": [{k: v for k, v in r.items() if k != "_w"} for r in rows]},
                      fh, indent=2)
        print("  wrote {}_comparison.csv / .json".format(args.out))
        _init_mpl()
        op = overlay_profiles(ra, rb, la, lb, args.out + "_overlay_profiles.png")
        sp = scorecard(rows, la, lb, args.out + "_scorecard.png")
        for f in (op, sp):
            if f:
                print("  wrote {}".format(f))
    return ra, rb, rows


if __name__ == "__main__":
    main()
