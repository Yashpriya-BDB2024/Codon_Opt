# -*- coding: utf-8 -*-
"""
codon_features.py  --  Single-sequence codon / mRNA feature extractor
=====================================================================

Takes one coding DNA sequence (CDS) and computes the selected panel of scores,
each with a positional profile wherever one is meaningful. mRNA secondary
structure uses **seqfold** (MIT); melting temperatures use an in-house
nearest-neighbour model (SantaLucia 1998), so there is no non-commercial
dependency anywhere in the path.

Scores computed (scalar + profile where noted)
----------------------------------------------
Codon usage / translation
  - CAI                      scalar + rolling profile
  - Rare codon %             scalar + rolling profile
  - ENC / Nc                 scalar + windowed profile
  - ENC' (GC3-expected)      scalar (+ deviation) + windowed profile
  - %MinMax                  profile + summary
  - Codon autocorrelation    scalar (lag-1) + ACF-vs-lag profile
  - 5' tAI ramp              scalar + rolling tAI profile
Composition
  - GC% overall              scalar + sliding profile
  - GC% max (60bp)           scalar
  - GC3 content %            scalar + windowed profile
  - CpG density (/100bp)     scalar + sliding profile
Structure (seqfold)
  - Positional dG array      profile (+ min / mean)
  - TIS accessibility        scalar (5' window dG)
  - Stable-structure count   scalar (windows below a dG cutoff)
  - Hairpin count (all)      scalar + sliding density profile
  - Hairpin count (5')       scalar
Liabilities / synthesis
  - Cryptic splice sites     scalar + positions
  - Homopolymer runs (>=6)   scalar + positions
  - Total restriction sites  scalar + per-enzyme + positions
  - Repeat count (>=10bp)    scalar
  - Repeat count (>=20bp)    scalar
  - Kozak context strength   scalar (needs start context; pass --utr5 for -3)
  - Tm + fragment balancing  scalar summary + per-fragment profile

Dependencies: numpy (BSD), seqfold (MIT). Optional: pandas (BSD) for CSV,
matplotlib (BSD-compat) for --plots. All commercial-use-safe.

Reference data is ALWAYS supplied by the user as input files -- nothing is ever
auto-downloaded. Codon usage comes from --codon-table (a CSV), and tRNA gene
copy numbers from --tgcn (a CSV). See DATA PROVENANCE below.

------------------------------------------------------------------------------
DEFAULTS  (every tunable lives in the DEFAULTS dict below -- nothing is buried
          in a function signature; change behaviour in one place)
------------------------------------------------------------------------------
  rare_threshold      0.3    codon with w=f/f_max below this is "rare"
  codon_window        18     codons, for rolling CAI / rare / tAI / %MinMax
  enc_window_codons   60     codons, step 15, for the windowed-ENC profile
  gc_window           45     nt, step 9, for the GC profile
  gc_max_window       60     nt, non-overlapping, for the GC%-max scalar
  cpg_window          50     nt, step 10, for the CpG-density profile
  mfe_window          40     nt, step 12, seqfold dG profile
  tis_window          48     nt from the 5' end, for TIS accessibility
  stable_dg_cutoff   -15.0   kcal/mol; windows below this count as "stable"
  hairpin_stem        6      nt stem for the hairpin heuristic
  hairpin_loop_min    3      nt minimum loop
  hairpin_window      200    nt search window for a stem's reverse complement
  hairpin_5p_region   100    nt, the "5' region" for the 5' hairpin count
  ramp_codons         30     codons, the 5' block for the tAI ramp
  autocorr_max_lag    20     codons, max lag for the autocorrelation profile
  tm_frag             60     nt synthesis fragment size for Tm balancing
  tm_na_mM            50.0    mM [Na+] for the nearest-neighbour Tm
  tm_oligo_nM         250.0   nM strand concentration for Tm
  repeat_k1 / repeat_k2  10 / 20   k-mer lengths for the two repeat counts

------------------------------------------------------------------------------
DATA PROVENANCE  (every non-trivial constant, and where it comes from)
------------------------------------------------------------------------------
  Genetic code .......... standard NCBI translation table 1 (textbook).
  Codon usage tables .... ALWAYS supplied via --codon-table (a CSV:
                          amino_acid,codon,fraction). Use tables from CoCoPUTs
                          (Alexaki et al. 2019, J Mol Biol 431:2434) for human
                          (9606), E. coli (316407) and CHO (Cricetulus griseus,
                          10029). A small inline human/E. coli snapshot (Kazusa;
                          Nakamura et al. 2000, Nucleic Acids Res 28:292) exists
                          only as an offline fallback for --host human/e_coli;
                          it is never downloaded, and --codon-table overrides it.
  tRNA gene copy numbers  ALWAYS supplied via --tgcn (a CSV: anticodon,count),
                          from GtRNAdb (Chan & Lowe 2016, Nucleic Acids Res
                          44:D184). Nothing is bundled; without --tgcn, tAI is
                          None. Never auto-downloaded.
  tAI weighting ......... dos Reis, Savva & Wernisch 2004, Nucleic Acids Res
                          32:5036 -- optimised s-values [0,0,0,0,0.41,0.28,
                          0.9999,0.68,0.89], reimplemented from the paper (the
                          reference R package is GPL and is NOT used here).
  ENC / Nc .............. Wright 1990, Gene 87:23. ENC' expected curve:
                          Wright 1990 / Novembre 2002, Mol Biol Evol 19:1390.
  %MinMax ............... Clarke & Clark 2008, BMC Genomics 9:222.
  CAI ................... Sharp & Li 1987, Nucleic Acids Res 15:1281.
  Restriction sites ..... recognition sequences from REBASE (Roberts et al.
                          2015, Nucleic Acids Res 43:D298); the bundled set is a
                          common cloning/MCS subset, extendable via --enzymes.
  Splice-site consensus . Shapiro & Senapathy 1987, Nucleic Acids Res 15:7155
                          (donor/acceptor/branch consensus motifs).
  Kozak context ......... Kozak 1987, Nucleic Acids Res 15:8125 (GCCRCCATGG).
  Melting temperature ... nearest-neighbour unified parameters, SantaLucia
                          1998, PNAS 95:1460 (implemented in-house; Biopython is
                          NOT used, so installing it does not change any Tm).
  mRNA structure ........ seqfold (MIT), Nussinov/Zuker-style MFE folding with
                          Turner energies.

CLI
---
    python3 codon_features.py --seq ATGGAA... --host human
    python3 codon_features.py --fasta cds.fasta --host human --out run --csv --plots
    # CHO host + tAI, using files built by build_reference_data.py:
    python3 codon_features.py --seq ATG... --codon-table cho_cocoputs.csv \
        --host-label CHO --tgcn cho_gtrnadb.csv --utr5 GCCACC --plots

Library
-------
    from codon_features import compute_features, DEFAULTS
    res = compute_features("ATGGAA...", host="human")
    res["scores"]["CAI"], res["profiles"]["codon_window"]["minmax"]
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from collections import defaultdict, Counter

import numpy as np

# ===========================================================================
# DEFAULTS -- the single source of truth for every tunable parameter.
# compute_features() reads from here; the CLI exposes each as a flag and
# prints the resolved values so a blind run still shows what was used.
# ===========================================================================
DEFAULTS = {
    "rare_threshold": 0.3,
    "codon_window": 18,
    "enc_window_codons": 60,
    "enc_window_step": 15,
    "gc_window": 45,
    "gc_window_step": 9,
    "gc_max_window": 60,
    "cpg_window": 50,
    "cpg_window_step": 10,
    "mfe_window": 40,
    "mfe_window_step": 12,
    "tis_window": 48,
    "stable_dg_cutoff": -15.0,
    "hairpin_stem": 6,
    "hairpin_loop_min": 3,
    "hairpin_window": 200,
    "hairpin_5p_region": 100,
    "hairpin_density_window": 60,
    "hairpin_density_step": 12,
    "ramp_codons": 30,
    "autocorr_max_lag": 20,
    "tm_frag": 60,
    "tm_na_mM": 50.0,
    "tm_oligo_nM": 250.0,
    "repeat_k1": 10,
    "repeat_k2": 20,
    "repeat_min_copies": 2,
    "gc3_window": 20,
    "longest_repeat_min": 8,
}

# ---------------------------------------------------------------------------
# Genetic code + host tables (human / e_coli built in)
# ---------------------------------------------------------------------------
GENETIC_CODE = {
    'TTT':'F','TTC':'F','TTA':'L','TTG':'L','CTT':'L','CTC':'L','CTA':'L','CTG':'L',
    'ATT':'I','ATC':'I','ATA':'I','ATG':'M','GTT':'V','GTC':'V','GTA':'V','GTG':'V',
    'TCT':'S','TCC':'S','TCA':'S','TCG':'S','CCT':'P','CCC':'P','CCA':'P','CCG':'P',
    'ACT':'T','ACC':'T','ACA':'T','ACG':'T','GCT':'A','GCC':'A','GCA':'A','GCG':'A',
    'TAT':'Y','TAC':'Y','TAA':'*','TAG':'*','CAT':'H','CAC':'H','CAA':'Q','CAG':'Q',
    'AAT':'N','AAC':'N','AAA':'K','AAG':'K','GAT':'D','GAC':'D','GAA':'E','GAG':'E',
    'TGT':'C','TGC':'C','TGA':'*','TGG':'W','CGT':'R','CGC':'R','CGA':'R','CGG':'R',
    'AGT':'S','AGC':'S','AGA':'R','AGG':'R','GGT':'G','GGC':'G','GGA':'G','GGG':'G',
}
STOP_CODONS = {'TAA', 'TAG', 'TGA'}
_COMPLEMENT = str.maketrans("ATGCN", "TACGN")

# Inline Kazusa snapshots (taxid 9606 / 316407) kept ONLY as an offline fallback
# for --host human / e_coli. Nothing is ever downloaded. For real work pass
# --codon-table with a CoCoPUTs CSV (human, E. coli and CHO); that overrides
# these. Source of the snapshot: Kazusa (Nakamura et al. 2000, NAR 28:292).
HUMAN_CODON_TABLE = {
    'A':{'GCT':0.27,'GCC':0.40,'GCA':0.23,'GCG':0.11},
    'R':{'CGT':0.08,'CGC':0.19,'CGA':0.11,'CGG':0.21,'AGA':0.20,'AGG':0.20},
    'N':{'AAT':0.46,'AAC':0.54},'D':{'GAT':0.46,'GAC':0.54},'C':{'TGT':0.45,'TGC':0.55},
    'Q':{'CAA':0.27,'CAG':0.73},'E':{'GAA':0.42,'GAG':0.58},
    'G':{'GGT':0.16,'GGC':0.34,'GGA':0.25,'GGG':0.25},'H':{'CAT':0.41,'CAC':0.59},
    'I':{'ATT':0.36,'ATC':0.48,'ATA':0.16},
    'L':{'TTA':0.07,'TTG':0.13,'CTT':0.13,'CTC':0.20,'CTA':0.07,'CTG':0.41},
    'K':{'AAA':0.42,'AAG':0.58},'M':{'ATG':1.00},'F':{'TTT':0.45,'TTC':0.55},
    'P':{'CCT':0.28,'CCC':0.33,'CCA':0.27,'CCG':0.11},
    'S':{'TCT':0.15,'TCC':0.22,'TCA':0.15,'TCG':0.06,'AGT':0.15,'AGC':0.24},
    'T':{'ACT':0.25,'ACC':0.36,'ACA':0.28,'ACG':0.11},'W':{'TGG':1.00},
    'Y':{'TAT':0.43,'TAC':0.57},'V':{'GTT':0.18,'GTC':0.24,'GTA':0.11,'GTG':0.47},
    '*':{'TAA':0.30,'TAG':0.24,'TGA':0.47},
}
ECOLI_CODON_TABLE = {
    'A':{'GCT':0.17,'GCC':0.26,'GCA':0.22,'GCG':0.35},
    'R':{'CGT':0.36,'CGC':0.36,'CGA':0.07,'CGG':0.11,'AGA':0.07,'AGG':0.04},
    'N':{'AAT':0.49,'AAC':0.51},'D':{'GAT':0.63,'GAC':0.37},'C':{'TGT':0.46,'TGC':0.54},
    'Q':{'CAA':0.34,'CAG':0.66},'E':{'GAA':0.68,'GAG':0.32},
    'G':{'GGT':0.35,'GGC':0.37,'GGA':0.13,'GGG':0.15},'H':{'CAT':0.57,'CAC':0.43},
    'I':{'ATT':0.51,'ATC':0.42,'ATA':0.07},
    'L':{'TTA':0.14,'TTG':0.13,'CTT':0.12,'CTC':0.10,'CTA':0.04,'CTG':0.47},
    'K':{'AAA':0.74,'AAG':0.26},'M':{'ATG':1.00},'F':{'TTT':0.58,'TTC':0.42},
    'P':{'CCT':0.18,'CCC':0.13,'CCA':0.20,'CCG':0.49},
    'S':{'TCT':0.17,'TCC':0.15,'TCA':0.14,'TCG':0.14,'AGT':0.16,'AGC':0.25},
    'T':{'ACT':0.19,'ACC':0.40,'ACA':0.17,'ACG':0.25},'W':{'TGG':1.00},
    'Y':{'TAT':0.59,'TAC':0.41},'V':{'GTT':0.28,'GTC':0.20,'GTA':0.17,'GTG':0.35},
    '*':{'TAA':0.61,'TAG':0.09,'TGA':0.30},
}
BUILTIN_TABLES = {'human': HUMAN_CODON_TABLE, 'h_sapiens': HUMAN_CODON_TABLE,
                  'e_coli': ECOLI_CODON_TABLE, 'ecoli': ECOLI_CODON_TABLE}

# Restriction recognition sequences from REBASE (Roberts et al. 2015, NAR
# 43:D298; http://rebase.neb.com). This is a common cloning / Golden-Gate /
# MCS subset, NOT all of REBASE (which lists thousands). Extend or replace at
# runtime with --enzymes name:SITE,name:SITE or a CSV (name,site). Sites are
# plain A/C/G/T and matched on both strands (no IUPAC expansion).
RESTRICTION_SITES = {
    # Type IIS (Golden Gate / MoClo)
    "BsaI": "GGTCTC", "BsmBI": "CGTCTC", "BbsI": "GAAGAC", "SapI": "GCTCTTC",
    "AarI": "CACCTGC",
    # Common 6-cutters (cloning / MCS)
    "EcoRI": "GAATTC", "BamHI": "GGATCC", "HindIII": "AAGCTT", "XhoI": "CTCGAG",
    "XbaI": "TCTAGA", "SalI": "GTCGAC", "NheI": "GCTAGC", "NcoI": "CCATGG",
    "NdeI": "CATATG", "KpnI": "GGTACC", "SacI": "GAGCTC", "PstI": "CTGCAG",
    "EcoRV": "GATATC", "HpaI": "GTTAAC", "SmaI": "CCCGGG", "AgeI": "ACCGGT",
    "MluI": "ACGCGT", "SpeI": "ACTAGT", "ClaI": "ATCGAT", "AflII": "CTTAAG",
    "BglII": "AGATCT", "DraI": "TTTAAA", "PacI": "TTAATTAA",
    # 8-cutters (rare cutters for large constructs)
    "NotI": "GCGGCCGC", "AscI": "GGCGCGCC", "FseI": "GGCCGGCC", "PmeI": "GTTTAAAC",
    "SbfI": "CCTGCAGG", "SwaI": "ATTTAAAT",
}

# Splice-site consensus motifs (vertebrate), from Shapiro & Senapathy 1987
# (NAR 15:7155). These are short consensus strings used as a first-pass scanner,
# NOT position-weight matrices; treat hits as candidates to inspect, not calls.
SPLICE_SITES = {
    "5prime_donor_GTAAG": "GTAAG",      # exon|GT AAG...  (canonical 5' donor)
    "5prime_donor_GTGAG": "GTGAG",
    "3prime_acceptor_poly": "TTTTTAG",  # polypyrimidine tract ...AG|exon
    "3prime_acceptor_CAG": "TTTCAG",
    "branch_point": "TACTAAC",          # branch-point A consensus
}

# tRNA gene copy numbers are NOT hardcoded. The earlier inline numbers were
# approximate (memory-derived) and have been removed to avoid shipping
# unverified data. tAI loads an authoritative anticodon->count table from a CSV
# (two columns: anticodon,count) sourced from GtRNAdb (Chan & Lowe 2016), via
# --tgcn or build_reference_data.py. Without such a file, tAI returns None.
def load_tgcn(path):
    """Load a GtRNAdb-derived tRNA gene copy-number table: CSV/TSV with columns
    anticodon,count (anticodon written 5'->3', DNA letters). Returns {anticodon: count}."""
    import csv as _csv
    sep = "\t" if path.lower().endswith(".tsv") else ","
    gcn = {}
    with open(path) as fh:
        reader = _csv.reader(fh, delimiter=sep)
        header = next(reader, None)
        cols = [c.strip().lower() for c in header] if header else []
        ai = cols.index("anticodon") if "anticodon" in cols else 0
        ci = cols.index("count") if "count" in cols else 1
        if "anticodon" not in cols and header and len(header) >= 2:
            # first row was data, not a header
            try:
                gcn[header[ai].strip().upper().replace("U", "T")] = int(float(header[ci]))
            except (ValueError, IndexError):
                pass
        for row in reader:
            if len(row) <= max(ai, ci):
                continue
            anti = row[ai].strip().upper().replace("U", "T")
            if anti and all(b in "ATGC" for b in anti) and len(anti) == 3:
                try:
                    gcn[anti] = gcn.get(anti, 0) + int(float(row[ci]))
                except ValueError:
                    pass
    return gcn


# ---------------------------------------------------------------------------
# Sequence helpers
# ---------------------------------------------------------------------------
def clean_seq(seq):
    if not seq or not isinstance(seq, str):
        return ""
    seq = "".join(seq.split()).upper().replace("U", "T")
    return "".join(b for b in seq if b in "ATGCN")


def reverse_complement(seq):
    return seq.translate(_COMPLEMENT)[::-1]


def strip_trailing_stop(seq):
    return seq[:-3] if len(seq) >= 3 and seq[-3:] in STOP_CODONS else seq


def codons_of(seq):
    seq = strip_trailing_stop(clean_seq(seq))
    return [seq[i:i+3] for i in range(0, len(seq) - 2, 3) if len(seq[i:i+3]) == 3]


def coding_codons(seq):
    return [c for c in codons_of(seq) if GENETIC_CODE.get(c) not in (None, '*')]


def normalise_table(raw):
    tbl = {}
    for aa, codons in raw.items():
        codons = {c.upper(): float(v) for c, v in codons.items() if v is not None}
        tot = sum(codons.values())
        if tot > 0:
            tbl[aa] = {c: v / tot for c, v in codons.items()}
    return tbl


def load_codon_table(spec, label=None):
    if isinstance(spec, dict):
        return normalise_table(spec), (label or "custom")
    key = str(spec).strip(); low = key.lower()
    if low in BUILTIN_TABLES:
        return normalise_table(BUILTIN_TABLES[low]), (label or low)
    if os.path.exists(key):
        if key.lower().endswith((".csv", ".tsv")):
            return _load_csv(key), (label or os.path.splitext(os.path.basename(key))[0])
        if key.lower().endswith(".json"):
            return _load_json(key), (label or os.path.splitext(os.path.basename(key))[0])
    raise ValueError("Unknown host '{}'. Use human/e_coli or a CSV/JSON table path.".format(key))


def _load_csv(path):
    import pandas as pd
    sep = "\t" if path.lower().endswith(".tsv") else ","
    df = pd.read_csv(path, sep=sep); df.columns = [c.strip().lower() for c in df.columns]
    codon_col = next((c for c in ("codon", "triplet") if c in df.columns), None)
    val_col = next((c for c in ("fraction","frequency","freq","count","proportion","number") if c in df.columns), None)
    if not codon_col or not val_col:
        raise ValueError("CSV needs a codon column and a fraction/frequency/count column.")
    raw = defaultdict(dict)
    for _, r in df.iterrows():
        c = str(r[codon_col]).strip().upper().replace("U", "T")
        if c in GENETIC_CODE:
            try: raw[GENETIC_CODE[c]][c] = float(r[val_col])
            except (ValueError, TypeError): pass
    return normalise_table(raw)


def _load_json(path):
    with open(path) as fh:
        data = json.load(fh)
    if all(isinstance(v, dict) for v in data.values()):
        return normalise_table(data)
    raw = defaultdict(dict)
    for c, v in data.items():
        cc = str(c).strip().upper().replace("U", "T")
        if cc in GENETIC_CODE:
            raw[GENETIC_CODE[cc]][cc] = float(v)
    return normalise_table(raw)


# ---------------------------------------------------------------------------
# Codon-usage scores
# ---------------------------------------------------------------------------
def adaptiveness_weights(codon_table):
    """w = f / f_max within each amino-acid family (CAI relative adaptiveness)."""
    maxf = {aa: max(c.values()) for aa, c in codon_table.items() if c}
    w = {}
    for aa, fam in codon_table.items():
        fm = maxf.get(aa, 1.0)
        for c, f in fam.items():
            w[c] = (f / fm) if fm > 0 else 0.0
    return w


def cai(seq, codon_table):
    w = adaptiveness_weights(codon_table)
    logs = [math.log(w[c]) for c in coding_codons(seq)
            if c in w and w[c] > 0 and len(codon_table.get(GENETIC_CODE[c], {})) > 1]
    return round(math.exp(sum(logs) / len(logs)), 4) if logs else None


def rolling_cai(seq, codon_table, window=18):
    w = adaptiveness_weights(codon_table)
    series = [math.log(w[c]) if (c in w and w[c] > 0) else math.log(1e-3)
              for c in coding_codons(seq)
              if len(codon_table.get(GENETIC_CODE[c], {})) > 1]
    idx, vals = [], []
    for i in range(len(series) - window + 1):
        idx.append(i + window // 2)
        vals.append(round(math.exp(sum(series[i:i+window]) / window), 4))
    return idx, vals


def rare_codon_pct(seq, codon_table, threshold=0.3):
    w = adaptiveness_weights(codon_table)
    cc = [c for c in coding_codons(seq)]
    if not cc:
        return None
    rare = sum(1 for c in cc if w.get(c, 0.0) < threshold)
    return round(rare / len(cc) * 100, 2)


def rolling_rare(seq, codon_table, threshold=0.3, window=18):
    w = adaptiveness_weights(codon_table)
    flags = [1 if w.get(c, 0.0) < threshold else 0 for c in coding_codons(seq)]
    idx, vals = [], []
    for i in range(len(flags) - window + 1):
        idx.append(i + window // 2)
        vals.append(round(sum(flags[i:i+window]) / window * 100, 2))
    return idx, vals


# --- ENC / Nc (Wright 1990) and ENC' (GC3-expected) ------------------------
def _family_homozygosity(codon_list):
    """F = (n*sum(p^2) - 1)/(n-1) for one amino-acid family's codon counts."""
    n = sum(codon_list.values())
    if n <= 1:
        return None
    s = sum((c / n) ** 2 for c in codon_list.values())
    f = (n * s - 1) / (n - 1)
    return f if f > 0 else None


def enc(seq):
    """Effective number of codons (Wright 1990). Returns Nc capped at 61."""
    counts = Counter(coding_codons(seq))
    fam_counts = defaultdict(lambda: defaultdict(int))
    for c, n in counts.items():
        fam_counts[GENETIC_CODE[c]][c] += n
    deg = {}  # amino acid -> degeneracy class (2,3,4,6)
    by_aa_codons = defaultdict(list)
    for c, aa in GENETIC_CODE.items():
        if aa != '*':
            by_aa_codons[aa].append(c)
    for aa, cs in by_aa_codons.items():
        deg[aa] = len(cs)
    classF = defaultdict(list)
    for aa, cl in fam_counts.items():
        k = deg[aa]
        if k == 1:
            continue
        f = _family_homozygosity(cl)
        if f is not None:
            classF[k].append(f)
    def mean_or(cls, fallback):
        return (sum(classF[cls]) / len(classF[cls])) if classF.get(cls) else fallback
    F2 = mean_or(2, None); F4 = mean_or(4, None); F6 = mean_or(6, None)
    if F2 is None or F4 is None:
        return None
    if F6 is None:
        F6 = F4
    F3 = mean_or(3, (F2 + F4) / 2)  # Ile is the only 3-fold; estimate if absent
    nc = 2 + 9 / F2 + 1 / F3 + 5 / F4 + 3 / F6
    return round(min(nc, 61.0), 2)


def enc_expected_from_gc3(gc3_frac):
    """Wright's null-model Nc expected from background GC3 (ENC' reference curve)."""
    s = gc3_frac
    denom = s ** 2 + (1 - s) ** 2
    if denom == 0:
        return None
    return round(min(2 + s + 29 / denom, 61.0), 2)


def windowed_enc(seq, window_codons=60, step=15):
    cc = coding_codons(seq)
    idx, vals = [], []
    for i in range(0, max(0, len(cc) - window_codons) + 1, step):
        sub = cc[i:i + window_codons]
        if len(sub) < window_codons:
            break
        subseq = "".join(sub)
        vals.append(enc(subseq)); idx.append(i + window_codons // 2)
    return idx, vals


# --- %MinMax (Clarke & Clark 2008) -----------------------------------------
def minmax_profile(seq, codon_table, window=18):
    cc = coding_codons(seq)
    maxf = {aa: max(c.values()) for aa, c in codon_table.items()}
    minf = {aa: min(c.values()) for aa, c in codon_table.items()}
    avgf = {aa: sum(c.values()) / len(c) for aa, c in codon_table.items()}
    idx, vals = [], []
    for i in range(len(cc) - window + 1):
        wc = cc[i:i+window]
        act = mx = mn = av = 0.0
        for c in wc:
            aa = GENETIC_CODE[c]
            act += codon_table[aa].get(c, 0.0); mx += maxf[aa]; mn += minf[aa]; av += avgf[aa]
        if act >= av:
            val = (act - av) / (mx - av) * 100 if mx > av else 0.0
        else:
            val = -(av - act) / (av - mn) * 100 if av > mn else 0.0
        idx.append(i + window // 2); vals.append(round(val, 2))
    return idx, vals


# --- tAI, 5' ramp, autocorrelation -----------------------------------------
# Authoritative dos Reis, Savva & Wernisch (2004) formulation, reimplemented
# from the paper (the reference R package is GPL and is NOT used). The relative
# adaptiveness values (ws) are built from a GtRNAdb tRNA gene copy-number table.
# Validation: with GtRNAdb E. coli K-12 counts and sking="prokaryote", the ws
# reproduce the published E. coli tAI benchmark.
_TAI_S = [0.0, 0.0, 0.0, 0.0, 0.41, 0.28, 0.9999, 0.68, 0.89]  # optimised s-values
_STD_CODON_ORDER = [b1 + b2 + b3 for b1 in "TCAG" for b2 in "TCAG" for b3 in "TCAG"]


def compute_tai_ws(tgcn, sking="eukaryote"):
    """Relative adaptiveness w per sense codon (dos Reis 2004).
    `tgcn`: {anticodon(5'->3', DNA): gene copy number}. Returns {codon: w} or None.
    t[k] = copy number of the Watson-Crick anticodon of codon k (= revcomp)."""
    if not tgcn:
        return None
    t = [float(tgcn.get(reverse_complement(c), 0)) for c in _STD_CODON_ORDER]
    p = [1.0 - s for s in _TAI_S]
    W = [0.0] * 64
    for i in range(0, 64, 4):               # 16 boxes; 3rd base order T,C,A,G
        W[i]     = p[0] * t[i]     + p[4] * t[i + 1]   # NNT
        W[i + 1] = p[1] * t[i + 1] + p[5] * t[i]       # NNC
        W[i + 2] = p[2] * t[i + 2] + p[6] * t[i]       # NNA
        W[i + 3] = p[3] * t[i + 3] + p[7] * t[i + 2]   # NNG
    W[35] = p[3] * t[35]                      # Met (ATG): drop the ATA->ATG wobble
    if str(sking).lower().startswith("pro"):
        W[34] = 1.0 - 0.89                    # bacterial Ile (ATA), modified tRNA
    stops = {10, 11, 14}                       # TAA, TAG, TGA in this ordering
    sense = [k for k in range(64) if k not in stops]
    wmax = max((W[k] for k in sense), default=0.0)
    if wmax <= 0:
        return None
    w = {_STD_CODON_ORDER[k]: W[k] / wmax for k in sense}
    nz = [v for v in w.values() if v > 0]
    gm = math.exp(sum(math.log(v) for v in nz) / len(nz)) if nz else 0.0
    return {c: (v if v > 0 else gm) for c, v in w.items()}


def sking_for(host_label):
    return "prokaryote" if "coli" in (host_label or "").lower() else "eukaryote"


def tai_series(seq, ws, drop_met=True):
    """Per-codon ws along the CDS (for profiles/ramp). Drops Met by default."""
    if not ws:
        return None
    out = [ws[c] for c in coding_codons(seq)
           if c in ws and not (drop_met and GENETIC_CODE.get(c) == 'M')]
    return out or None


def tai(seq, ws):
    s = tai_series(seq, ws)
    if not s:
        return None
    logs = [math.log(v) for v in s if v > 0]
    return round(math.exp(sum(logs) / len(logs)), 4) if logs else None


def rolling_tai(seq, ws, window=18):
    s = tai_series(seq, ws)
    if not s:
        return [], []
    idx, vals = [], []
    for i in range(len(s) - window + 1):
        seg = [v for v in s[i:i+window] if v > 0]
        if seg:
            idx.append(i + window // 2)
            vals.append(round(math.exp(sum(math.log(v) for v in seg) / len(seg)), 4))
    return idx, vals


def tai_ramp(seq, ws, ramp_codons=30):
    """Ramp = geometric-mean tAI of the body minus that of the first
    `ramp_codons`. Positive => a slow 5' start (a translational ramp)."""
    s = tai_series(seq, ws)
    if not s or len(s) < ramp_codons * 2:
        return None
    head = [v for v in s[:ramp_codons] if v > 0]
    body = [v for v in s[ramp_codons:] if v > 0]
    if not head or not body:
        return None
    gm = lambda xs: math.exp(sum(math.log(v) for v in xs) / len(xs))
    head_tai, body_tai = gm(head), gm(body)
    return {"ramp": round(body_tai - head_tai, 4),
            "head_tai": round(head_tai, 4), "body_tai": round(body_tai, 4),
            "ramp_codons": ramp_codons}


def codon_autocorrelation(series, max_lag=20):
    """Autocorrelation (ACF) of a per-codon numeric series -- whether fast/slow
    codons cluster. Caller supplies the series (tAI ws if available, else the
    CAI relative-adaptiveness series). Returns (lag1, (lags, acf))."""
    if not series:
        return None, ([], [])
    x = np.array(series, dtype=float)
    x = x - x.mean()
    denom = float(np.dot(x, x))
    if denom == 0 or len(x) < max_lag + 2:
        return None, ([], [])
    lags, acf = [], []
    for k in range(1, min(max_lag, len(x) - 1) + 1):
        lags.append(k)
        acf.append(round(float(np.dot(x[:-k], x[k:]) / denom), 4))
    return (acf[0] if acf else None), (lags, acf)


def cai_weight_series(seq, codon_table):
    """Per-codon CAI relative adaptiveness w=f/f_max (fallback for autocorr)."""
    w = adaptiveness_weights(codon_table)
    return [w[c] for c in coding_codons(seq) if c in w]


# ---------------------------------------------------------------------------
# Composition
# ---------------------------------------------------------------------------
def gc_content(seq):
    seq = clean_seq(seq)
    return round(sum(1 for b in seq if b in "GC") / len(seq) * 100, 2) if seq else None


def gc_profile(seq, window=45, step=9):
    seq = clean_seq(seq)
    idx, vals = [], []
    for i in range(0, len(seq) - window + 1, step):
        idx.append(i + window // 2)
        vals.append(gc_content(seq[i:i+window]))
    return idx, vals


def gc_max_nonoverlap(seq, window=60):
    seq = clean_seq(seq)
    if len(seq) < window:
        return None
    vals = [gc_content(seq[i:i+window]) for i in range(0, len(seq) - window + 1, window)]
    return round(max(vals), 2) if vals else None


def gc3_content(seq):
    cc = codons_of(seq)
    thirds = [c[2] for c in cc]
    return round(sum(1 for b in thirds if b in "GC") / len(thirds) * 100, 2) if thirds else None


def gc3_profile(seq, window=20, step=1):
    cc = codons_of(seq)
    thirds = [1 if c[2] in "GC" else 0 for c in cc]
    idx, vals = [], []
    for i in range(len(thirds) - window + 1):
        idx.append(i + window // 2)
        vals.append(round(sum(thirds[i:i+window]) / window * 100, 2))
    return idx, vals


def cpg_density(seq):
    seq = clean_seq(seq)
    return round(seq.count("CG") / len(seq) * 100, 2) if seq else None


def cpg_profile(seq, window=50, step=10):
    seq = clean_seq(seq)
    idx, vals = [], []
    for i in range(0, len(seq) - window + 1, step):
        sub = seq[i:i+window]
        idx.append(i + window // 2)
        vals.append(round(sub.count("CG") / window * 100, 2))
    return idx, vals


# ---------------------------------------------------------------------------
# Structure (seqfold) + hairpins
# ---------------------------------------------------------------------------
def _folder():
    try:
        import seqfold
        def fold(s):
            try:
                return float(seqfold.dg(s, temp=37.0))
            except Exception:
                return None
        return fold
    except Exception:
        return None


def mfe_profile(seq, window=40, step=12):
    seq = clean_seq(seq)
    fold = _folder()
    if fold is None or len(seq) < window:
        return [], [], None
    idx, vals = [], []
    for i in range(0, len(seq) - window + 1, step):
        dg = fold(seq[i:i+window])
        if dg is not None:
            idx.append(i + window // 2); vals.append(round(dg, 2))
    engine = "seqfold" if vals else "unavailable"
    return idx, vals, engine


def tis_accessibility(seq, tis_window=48):
    seq = clean_seq(seq)
    fold = _folder()
    if fold is None or len(seq) < 10:
        return None
    return round(fold(seq[:tis_window]), 2)


def count_hairpins(seq, stem_size=6, loop_min=3, window=200):
    seq = clean_seq(seq)
    if len(seq) < stem_size * 2 + loop_min:
        return 0
    count = 0
    for i in range(len(seq) - stem_size):
        stem = seq[i:i+stem_size]; rc = reverse_complement(stem)
        s0 = i + stem_size + loop_min; s1 = min(i + window, len(seq) - stem_size)
        if s0 < s1 and rc in seq[s0:s1]:
            count += 1
    return count


def hairpin_density(seq, window=60, step=12, stem_size=6):
    seq = clean_seq(seq)
    idx, vals = [], []
    for i in range(0, max(0, len(seq) - window) + 1, step):
        sub = seq[i:i+window]
        idx.append(i + window // 2)
        vals.append(count_hairpins(sub, stem_size=stem_size, window=window))
    return idx, vals


# ---------------------------------------------------------------------------
# Liabilities / motifs
# ---------------------------------------------------------------------------
def scan_positions(seq, motifs, both_strands=True):
    seq = clean_seq(seq)
    hits = []; counts = defaultdict(int)
    for name, pat in motifs.items():
        pat = pat.upper()
        for strand, p in (("+", pat), ("-", reverse_complement(pat))):
            if strand == "-" and (not both_strands or p == pat):
                continue
            start = 0
            while True:
                j = seq.find(p, start)
                if j < 0:
                    break
                hits.append((name, strand, j)); counts[name] += 1; start = j + 1
    return counts, hits


def homopolymer_runs(seq, min_run=6):
    seq = clean_seq(seq)
    hits = []
    i = 0
    while i < len(seq):
        j = i
        while j < len(seq) and seq[j] == seq[i]:
            j += 1
        if j - i >= min_run:
            hits.append((seq[i], i, j - i))
        i = j
    return hits


def find_repetitions(seq, k=10, min_copies=2):
    seq = clean_seq(seq)
    if len(seq) < k * min_copies:
        return 0
    seen, count = set(), 0
    for i in range(len(seq) - k + 1):
        kmer = seq[i:i+k]
        if kmer in seen:
            continue
        seen.add(kmer)
        if seq.count(kmer) >= min_copies:
            count += 1
    return count


# ---------------------------------------------------------------------------
# Kozak context strength
# ---------------------------------------------------------------------------
def kozak_strength(cds, utr5=""):
    """Score the translation-initiation context against the Kozak consensus
    (gccRccATGG). Positions scored: -6..-1 (from utr5 if supplied), the ATG,
    and +4 (first base after ATG). Returns a 0-1 score over the positions
    that are actually available, plus the two decisive flags (-3 purine, +4=G).
    With CDS-only input only +4 is informative; pass --utr5 for -3/-6."""
    cds = clean_seq(cds); utr5 = clean_seq(utr5)
    if len(cds) < 4 or cds[:3] != "ATG":
        return {"score": None, "minus3_purine": None, "plus4_G": None,
                "note": "no ATG start or sequence too short"}
    consensus = {-6:"G", -5:"C", -4:"C", -3:"R", -2:"C", -1:"C", 4:"G"}  # R = A/G
    matches = total = 0
    minus3 = plus4 = None
    for pos, base in consensus.items():
        if pos < 0:
            if len(utr5) >= -pos:
                obs = utr5[pos]  # utr5[-k] = k-th from the 3' end of the UTR
                total += 1
                ok = (obs in "AG") if base == "R" else (obs == base)
                matches += int(ok)
                if pos == -3:
                    minus3 = obs in "AG"
        elif pos == 4:
            obs = cds[3]
            total += 1
            matches += int(obs == "G")
            plus4 = obs == "G"
    score = round(matches / total, 3) if total else None
    return {"score": score, "minus3_purine": minus3, "plus4_G": plus4,
            "positions_scored": total,
            "note": "pass --utr5 for -6..-1 context" if not utr5 else ""}


# ---------------------------------------------------------------------------
# Melting temperature (nearest-neighbour, SantaLucia 1998) + fragment balance
# ---------------------------------------------------------------------------
_NN_H = {'AA':-7.6,'TT':-7.6,'AT':-7.2,'TA':-7.2,'CA':-8.5,'TG':-8.5,'GT':-8.4,'AC':-8.4,
         'CT':-7.8,'AG':-7.8,'GA':-8.2,'TC':-8.2,'CG':-10.6,'GC':-9.8,'GG':-8.0,'CC':-8.0}
_NN_S = {'AA':-21.3,'TT':-21.3,'AT':-20.4,'TA':-21.3,'CA':-22.7,'TG':-22.7,'GT':-22.4,
         'AC':-22.4,'CT':-21.0,'AG':-21.0,'GA':-22.2,'TC':-22.2,'CG':-27.2,'GC':-24.4,
         'GG':-19.9,'CC':-19.9}


def tm_nn(seq, na_mM=50.0, oligo_nM=250.0):
    """Nearest-neighbour Tm (SantaLucia 1998 unified parameters), degC.
    Returns None for sequences too short for a stable estimate (< 8 nt)."""
    seq = clean_seq(seq)
    if len(seq) < 8 or any(b not in "ATGC" for b in seq):
        return None
    dH = dS = 0.0
    for i in range(len(seq) - 1):
        nn = seq[i:i+2]
        if nn not in _NN_H:
            return None
        dH += _NN_H[nn]; dS += _NN_S[nn]
    # terminal initiation corrections
    for end in (seq[0], seq[-1]):
        if end in "GC":
            dH += 0.1; dS += -2.8
        else:
            dH += 2.3; dS += 4.1
    R = 1.987
    ct = oligo_nM * 1e-9
    dS_salt = dS + 0.368 * (len(seq) - 1) * math.log(na_mM / 1000.0)
    denom = dS_salt + R * math.log(ct / 4.0)
    if abs(denom) < 1e-6:
        return None
    tm = (dH * 1000.0) / denom - 273.15
    if tm < -50 or tm > 150:
        return None
    return round(tm, 2)


def _fragment_bounds(n, frag):
    """Tile [0,n) into fragments of size `frag`, absorbing a short tail
    (< frag/2) into the previous fragment so no stub fragment is produced."""
    if n <= 0:
        return []
    bounds = [(i, min(i + frag, n)) for i in range(0, n, frag)]
    if len(bounds) >= 2 and (bounds[-1][1] - bounds[-1][0]) < frag / 2:
        s_prev, _ = bounds[-2]
        bounds[-2] = (s_prev, bounds[-1][1])
        bounds.pop()
    return bounds


def tm_fragments(seq, frag=60, na_mM=50.0, oligo_nM=250.0):
    """Tile the sequence into synthesis fragments and report per-fragment Tm
    plus a balance summary (spread = max-min, std). A short tail is merged
    into the previous fragment so it does not distort the balance."""
    seq = clean_seq(seq)
    idx, starts, ends, tms = [], [], [], []
    n = 0
    for (a, b) in _fragment_bounds(len(seq), frag):
        sub = seq[a:b]
        t = tm_nn(sub, na_mM, oligo_nM)
        if t is not None:
            idx.append(n); starts.append(a); ends.append(b); tms.append(t); n += 1
    summary = None
    if tms:
        summary = {"n_fragments": len(tms), "frag_size": frag,
                   "tm_mean": round(float(np.mean(tms)), 2),
                   "tm_std": round(float(np.std(tms)), 2),
                   "tm_min": round(min(tms), 2), "tm_max": round(max(tms), 2),
                   "tm_spread": round(max(tms) - min(tms), 2)}
    return summary, {"index": idx, "start": starts, "end": ends, "tm": tms}


# ===========================================================================
# Top-level: compute everything
# ===========================================================================
def compute_features(seq, host="human", host_label=None, codon_table=None,
                     tgcn=None, utr5="", name=None, **overrides):
    """Compute all scores + profiles for one CDS. Tunables come from DEFAULTS;
    pass any DEFAULTS key as a keyword to override it. `tgcn` is a GtRNAdb
    anticodon->count CSV path (or dict); without it, tAI is None."""
    cfg = {**DEFAULTS, **overrides}
    t0 = time.time()
    raw = clean_seq(seq)
    tbl, resolved_label = load_codon_table(codon_table if codon_table else host, host_label)
    hlabel = host_label or resolved_label
    if not raw:
        return {"name": name, "error": "empty/invalid sequence"}

    body = strip_trailing_stop(raw)
    translation_ok = (len(body) % 3 == 0) and not any(
        GENETIC_CODE.get(c) == '*' for c in [body[i:i+3] for i in range(0, len(body)-2, 3)])

    # tAI relative-adaptiveness (ws) from a GtRNAdb tGCN table, if supplied
    tgcn_map = tgcn if isinstance(tgcn, dict) else (load_tgcn(tgcn) if tgcn else None)
    ws = compute_tai_ws(tgcn_map, sking_for(hlabel)) if tgcn_map else None

    # --- scalars ---
    gc_ov = gc_content(raw)
    gc3 = gc3_content(raw)
    scores = {}
    scores["CAI"] = cai(raw, tbl)
    scores["rare_codon_pct"] = rare_codon_pct(raw, tbl, cfg["rare_threshold"])
    scores["ENC"] = enc(raw)
    scores["ENC_prime_expected"] = enc_expected_from_gc3(gc3 / 100.0) if gc3 is not None else None
    if scores["ENC"] is not None and scores["ENC_prime_expected"]:
        scores["ENC_deviation"] = round((scores["ENC_prime_expected"] - scores["ENC"])
                                        / scores["ENC_prime_expected"], 4)
    else:
        scores["ENC_deviation"] = None
    scores["tAI"] = tai(raw, ws)
    scores["tAI_available"] = ws is not None
    if ws is None:
        scores["tAI_note"] = "no tRNA table supplied; pass --tgcn (GtRNAdb)"
    ramp = tai_ramp(raw, ws, cfg["ramp_codons"])
    scores["tAI_ramp"] = ramp["ramp"] if ramp else None
    scores["tAI_head"] = ramp["head_tai"] if ramp else None
    scores["tAI_body"] = ramp["body_tai"] if ramp else None
    # autocorrelation: tAI series if available, else the CAI-weight series
    ac_series = tai_series(raw, ws) if ws else cai_weight_series(raw, tbl)
    lag1, acf_profile = codon_autocorrelation(ac_series, cfg["autocorr_max_lag"])
    scores["codon_autocorr_lag1"] = lag1
    scores["codon_autocorr_source"] = "tAI" if ws else "CAI_weights"
    scores["GC_pct"] = gc_ov
    scores["GC_max_60bp"] = gc_max_nonoverlap(raw, cfg["gc_max_window"])
    scores["GC3_pct"] = gc3
    scores["CpG_density_per100bp"] = cpg_density(raw)
    # structure
    mfe_idx, mfe_vals, mfe_engine = mfe_profile(raw, cfg["mfe_window"], cfg["mfe_window_step"])
    scores["MFE_engine"] = mfe_engine
    scores["TIS_accessibility_5p"] = tis_accessibility(raw, cfg["tis_window"])
    if mfe_vals:
        scores["MFE_min_window"] = round(min(mfe_vals), 2)
        scores["MFE_mean_window"] = round(float(np.mean(mfe_vals)), 2)
        scores["stable_structure_count"] = int(sum(1 for v in mfe_vals if v < cfg["stable_dg_cutoff"]))
        scores["stable_dg_cutoff"] = cfg["stable_dg_cutoff"]
    else:
        scores["MFE_min_window"] = scores["MFE_mean_window"] = None
        scores["stable_structure_count"] = None
    scores["hairpin_count_all"] = count_hairpins(raw, cfg["hairpin_stem"], cfg["hairpin_loop_min"], cfg["hairpin_window"])
    scores["hairpin_count_5prime"] = count_hairpins(raw[:cfg["hairpin_5p_region"]], cfg["hairpin_stem"])
    # liabilities
    rs_counts, rs_hits = scan_positions(raw, RESTRICTION_SITES, both_strands=True)
    sp_counts, sp_hits = scan_positions(raw, SPLICE_SITES, both_strands=False)
    hp_runs = homopolymer_runs(raw, 6)
    scores["restriction_sites_total"] = int(sum(rs_counts.values()))
    for enz in RESTRICTION_SITES:
        scores["RS_" + enz] = int(rs_counts.get(enz, 0))
    scores["splice_sites_total"] = int(sum(sp_counts.values()))
    scores["homopolymer_runs_ge6"] = len(hp_runs)
    scores["repeat_count_10bp"] = find_repetitions(raw, cfg["repeat_k1"], cfg["repeat_min_copies"])
    scores["repeat_count_20bp"] = find_repetitions(raw, cfg["repeat_k2"], cfg["repeat_min_copies"])
    # start codon / Kozak (antibody CDSs begin at the signal-peptide Met = ATG;
    # a VH/VL fragment pasted without its leader does NOT start with ATG -> see note)
    scores["start_is_ATG"] = (raw[:3] == "ATG")
    first_atg = raw.find("ATG")
    scores["first_ATG_pos"] = first_atg if first_atg >= 0 else None
    koz = kozak_strength(raw, utr5)
    scores["kozak_score"] = koz["score"]
    scores["kozak_minus3_purine"] = koz["minus3_purine"]
    scores["kozak_plus4_G"] = koz["plus4_G"]
    scores["kozak_note"] = koz["note"] if scores["start_is_ATG"] else \
        "sequence does not begin with ATG (e.g. a VH/VL fragment); Kozak scored only if an ATG start is present"
    # Tm
    tm_summary, tm_prof = tm_fragments(raw, cfg["tm_frag"], cfg["tm_na_mM"], cfg["tm_oligo_nM"])
    if tm_summary:
        scores.update({"tm_mean": tm_summary["tm_mean"], "tm_std": tm_summary["tm_std"],
                       "tm_min": tm_summary["tm_min"], "tm_max": tm_summary["tm_max"],
                       "tm_spread": tm_summary["tm_spread"], "tm_frag_size": tm_summary["frag_size"]})

    # --- profiles ---
    rc_idx, rc_vals = rolling_cai(raw, tbl, cfg["codon_window"])
    rr_idx, rr_vals = rolling_rare(raw, tbl, cfg["rare_threshold"], cfg["codon_window"])
    rt_idx, rt_vals = rolling_tai(raw, ws, cfg["codon_window"])
    mm_idx, mm_vals = minmax_profile(raw, tbl, cfg["codon_window"])
    g3_idx, g3_vals = gc3_profile(raw, cfg["gc3_window"])
    en_idx, en_vals = windowed_enc(raw, cfg["enc_window_codons"], cfg["enc_window_step"])
    gc_pidx, gc_pvals = gc_profile(raw, cfg["gc_window"], cfg["gc_window_step"])
    cpg_pidx, cpg_pvals = cpg_profile(raw, cfg["cpg_window"], cfg["cpg_window_step"])
    hp_pidx, hp_pvals = hairpin_density(raw, cfg["hairpin_density_window"], cfg["hairpin_density_step"], cfg["hairpin_stem"])

    # %MinMax summary
    if mm_vals:
        scores["minmax_mean"] = round(float(np.mean(mm_vals)), 2)
        scores["minmax_min"] = round(min(mm_vals), 2)
        scores["minmax_pct_rare_windows"] = round(sum(1 for v in mm_vals if v < 0) / len(mm_vals) * 100, 1)

    profiles = {
        "codon_window": {"rolling_cai": {"index": rc_idx, "value": rc_vals},
                          "rolling_rare_pct": {"index": rr_idx, "value": rr_vals},
                          "rolling_tai": {"index": rt_idx, "value": rt_vals},
                          "minmax": {"index": mm_idx, "value": mm_vals},
                          "gc3_window": {"index": g3_idx, "value": g3_vals},
                          "enc_window": {"index": en_idx, "value": en_vals}},
        "nt_window": {"gc": {"index": gc_pidx, "value": gc_pvals},
                      "cpg_density": {"index": cpg_pidx, "value": cpg_pvals},
                      "hairpin_density": {"index": hp_pidx, "value": hp_pvals}},
        "mfe_window": {"index": mfe_idx, "value": mfe_vals},
        "autocorrelation": {"lag": acf_profile[0], "acf": acf_profile[1]},
        "tm_fragments": tm_prof,
    }
    positions = {
        "restriction": [{"name": n, "strand": s, "pos": p} for (n, s, p) in rs_hits],
        "splice": [{"name": n, "strand": s, "pos": p} for (n, s, p) in sp_hits],
        "homopolymer": [{"base": b, "pos": p, "length": l} for (b, p, l) in hp_runs],
    }

    return {"name": name, "host": hlabel,
            "input": {"length_bp": len(raw), "codons": len(body) // 3,
                      "translation_ok": translation_ok},
            "scores": scores, "profiles": profiles, "positions": positions,
            "runtime_sec": round(time.time() - t0, 3)}


# ===========================================================================
# IO / CLI
# ===========================================================================
def read_fasta(path):
    name, chunks = None, []
    with open(path) as fh:
        for line in fh:
            line = line.rstrip()
            if line.startswith(">"):
                if name is not None:
                    yield name, "".join(chunks)
                name, chunks = line[1:].strip(), []
            elif line:
                chunks.append(line)
    if name is not None:
        yield name, "".join(chunks)


def write_profiles_csv(res, prefix):
    import pandas as pd
    outputs = []
    cw = res["profiles"]["codon_window"]
    # align codon-window profiles on a common index union
    frames = []
    for key, d in cw.items():
        if d["index"]:
            frames.append(pd.DataFrame({"codon_index": d["index"], key: d["value"]}))
    if frames:
        df = frames[0]
        for f in frames[1:]:
            df = df.merge(f, on="codon_index", how="outer")
        df = df.sort_values("codon_index")
        p = prefix + "_profile_codon.csv"; df.to_csv(p, index=False); outputs.append(p)
    # nt-window profiles
    ntw = res["profiles"]["nt_window"]; nframes = []
    for key, d in ntw.items():
        if d["index"]:
            nframes.append(pd.DataFrame({"nt_position": d["index"], key: d["value"]}))
    if nframes:
        df = nframes[0]
        for f in nframes[1:]:
            df = df.merge(f, on="nt_position", how="outer")
        df = df.sort_values("nt_position")
        p = prefix + "_profile_nt.csv"; df.to_csv(p, index=False); outputs.append(p)
    # mfe
    mw = res["profiles"]["mfe_window"]
    if mw["index"]:
        p = prefix + "_profile_mfe.csv"
        pd.DataFrame({"nt_position": mw["index"], "dG_kcal": mw["value"]}).to_csv(p, index=False)
        outputs.append(p)
    # autocorrelation
    ac = res["profiles"]["autocorrelation"]
    if ac["lag"]:
        p = prefix + "_autocorrelation.csv"
        pd.DataFrame({"lag": ac["lag"], "acf": ac["acf"]}).to_csv(p, index=False); outputs.append(p)
    # tm
    tm = res["profiles"]["tm_fragments"]
    if tm["index"]:
        p = prefix + "_tm_fragments.csv"
        pd.DataFrame(tm).to_csv(p, index=False); outputs.append(p)
    # positions
    posrows = []
    for cat, items in res["positions"].items():
        for it in items:
            row = {"category": cat}; row.update(it); posrows.append(row)
    if posrows:
        p = prefix + "_positions.csv"
        pd.DataFrame(posrows).to_csv(p, index=False); outputs.append(p)
    return outputs


def plot_profiles(res, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    cw = res["profiles"]["codon_window"]; ntw = res["profiles"]["nt_window"]
    mw = res["profiles"]["mfe_window"]; ac = res["profiles"]["autocorrelation"]
    tm = res["profiles"]["tm_fragments"]
    panels = [
        ("GC % (45nt window)", ntw["gc"]["index"], ntw["gc"]["value"], "nt", "#1565C0"),
        ("MFE dG (40nt window)", mw["index"], mw["value"], "nt", "#6A1B9A"),
        ("%MinMax (18-codon)", cw["minmax"]["index"], cw["minmax"]["value"], "codon", "#E65100"),
        ("Rolling CAI", cw["rolling_cai"]["index"], cw["rolling_cai"]["value"], "codon", "#2E7D32"),
        ("Rolling tAI", cw["rolling_tai"]["index"], cw["rolling_tai"]["value"], "codon", "#00838F"),
        ("Windowed ENC", cw["enc_window"]["index"], cw["enc_window"]["value"], "codon", "#AD1457"),
        ("CpG density /100bp", ntw["cpg_density"]["index"], ntw["cpg_density"]["value"], "nt", "#5D4037"),
        ("Autocorrelation (ACF)", ac["lag"], ac["acf"], "lag", "#37474F"),
        ("Fragment Tm", tm["index"], tm["tm"], "fragment", "#C62828"),
    ]
    panels = [p for p in panels if p[1]]
    n = len(panels)
    if n == 0:
        return None
    fig, axs = plt.subplots(n, 1, figsize=(11, 2.2 * n))
    if n == 1:
        axs = [axs]
    for ax, (title, idx, vals, xlab, color) in zip(axs, panels):
        if xlab in ("lag", "fragment"):
            ax.bar(idx, vals, color=color, alpha=0.85)
        else:
            ax.plot(idx, vals, color=color, lw=1.4)
            ax.fill_between(idx, vals, min(vals), color=color, alpha=0.08)
        ax.set_title(title, fontsize=10, loc="left", fontweight="bold")
        ax.set_xlabel(xlab); ax.grid(alpha=0.3)
    nm = res.get("name") or "sequence"
    fig.suptitle("Positional feature profiles — {}".format(nm), fontsize=13, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.99])
    fig.savefig(path, dpi=140, bbox_inches="tight"); plt.close(fig)
    return path


def _print_scores(res):
    print("=" * 60)
    print("  {}  ({} bp, {} codons, translation_ok={})".format(
        res.get("name") or "sequence", res["input"]["length_bp"],
        res["input"]["codons"], res["input"]["translation_ok"]))
    print("=" * 60)
    order = ["CAI", "rare_codon_pct", "ENC", "ENC_prime_expected", "ENC_deviation",
             "tAI", "tAI_ramp", "codon_autocorr_lag1", "minmax_mean", "minmax_pct_rare_windows",
             "GC_pct", "GC_max_60bp", "GC3_pct", "CpG_density_per100bp",
             "TIS_accessibility_5p", "MFE_min_window", "stable_structure_count",
             "hairpin_count_all", "hairpin_count_5prime",
             "splice_sites_total", "homopolymer_runs_ge6", "restriction_sites_total",
             "repeat_count_10bp", "repeat_count_20bp", "kozak_score",
             "tm_mean", "tm_spread"]
    for k in order:
        if k in res["scores"]:
            print("  {:<26} {}".format(k, res["scores"][k]))
    print("  {:<26} {}".format("runtime_sec", res.get("runtime_sec")))
    print()


def _parse_enzymes(spec):
    """Parse --enzymes: a CSV path (name,site) or an inline 'name:SITE,name:SITE'."""
    out = {}
    if os.path.exists(spec):
        import csv as _csv
        with open(spec) as fh:
            for row in _csv.reader(fh):
                if len(row) >= 2 and row[0].strip().lower() not in ("name", "enzyme"):
                    site = clean_seq(row[1])
                    if site:
                        out[row[0].strip()] = site
    else:
        for item in spec.split(","):
            if ":" in item:
                nm, site = item.split(":", 1)
                site = clean_seq(site)
                if site:
                    out[nm.strip()] = site
    return out or RESTRICTION_SITES


def main(argv=None):
    p = argparse.ArgumentParser(description="Single-sequence codon/mRNA feature extractor.")
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--seq")
    src.add_argument("--fasta")
    p.add_argument("--host", default="human")
    p.add_argument("--codon-table", dest="codon_table",
                   help="host codon table CSV/JSON (overrides --host); use for CHO")
    p.add_argument("--host-label", dest="host_label")
    p.add_argument("--tgcn", help="GtRNAdb anticodon,count CSV; enables tAI")
    p.add_argument("--utr5", default="", help="5' UTR / upstream bases for Kozak -6..-1")
    p.add_argument("--enzymes", help="override restriction set: 'name:SITE,name:SITE' or a CSV path (name,site)")
    # tunables -- defaults come from DEFAULTS; shown in --help and printed per run
    p.add_argument("--rare-threshold", dest="rare_threshold", type=float, default=DEFAULTS["rare_threshold"])
    p.add_argument("--codon-window", dest="codon_window", type=int, default=DEFAULTS["codon_window"])
    p.add_argument("--ramp-codons", dest="ramp_codons", type=int, default=DEFAULTS["ramp_codons"])
    p.add_argument("--stable-dg", dest="stable_dg_cutoff", type=float, default=DEFAULTS["stable_dg_cutoff"])
    p.add_argument("--tm-frag", dest="tm_frag", type=int, default=DEFAULTS["tm_frag"])
    p.add_argument("--tm-na", dest="tm_na_mM", type=float, default=DEFAULTS["tm_na_mM"])
    p.add_argument("--out", help="output prefix (writes <prefix>_scores.json)")
    p.add_argument("--csv", action="store_true", help="also write profile CSVs")
    p.add_argument("--plots", action="store_true", help="also write a profiles PNG")
    p.add_argument("--show-defaults", action="store_true", help="print all DEFAULTS and exit")
    args = p.parse_args(argv)

    if args.show_defaults:
        print("DEFAULTS (resolved tunables):")
        for k, v in DEFAULTS.items():
            print("  {:<22} {}".format(k, v))
        return

    # restriction override
    if args.enzymes:
        global RESTRICTION_SITES
        RESTRICTION_SITES = _parse_enzymes(args.enzymes)

    overrides = {"rare_threshold": args.rare_threshold, "codon_window": args.codon_window,
                 "ramp_codons": args.ramp_codons, "stable_dg_cutoff": args.stable_dg_cutoff,
                 "tm_frag": args.tm_frag, "tm_na_mM": args.tm_na_mM}
    cfg = {**DEFAULTS, **overrides}
    print("Run config (defaults unless overridden):")
    for k in ["rare_threshold", "codon_window", "ramp_codons", "stable_dg_cutoff",
              "mfe_window", "tis_window", "tm_frag", "tm_na_mM", "tm_oligo_nM",
              "gc_max_window", "hairpin_stem", "autocorr_max_lag"]:
        print("  {:<20} {}".format(k, cfg[k]))
    print("  tAI tRNA table       {}".format(args.tgcn or "(none -> tAI disabled)"))
    print()

    seqs = [("seq", args.seq)] if args.seq else list(read_fasta(args.fasta))
    results = []
    for nm, s in seqs:
        res = compute_features(s, host=args.host, host_label=args.host_label,
                               codon_table=args.codon_table, tgcn=args.tgcn,
                               utr5=args.utr5, name=nm, **overrides)
        results.append(res)
        if "error" in res:
            print("  {}: ERROR {}".format(nm, res["error"])); continue
        _print_scores(res)
        if args.out:
            prefix = args.out if len(seqs) == 1 else "{}_{}".format(args.out, nm)
            with open(prefix + "_scores.json", "w") as fh:
                json.dump({"name": res["name"], "host": res["host"], "input": res["input"],
                           "scores": res["scores"], "positions": res["positions"]}, fh, indent=2)
            print("  wrote {}_scores.json".format(prefix))
            if args.csv:
                for f in write_profiles_csv(res, prefix):
                    print("  wrote {}".format(f))
            if args.plots:
                pp = plot_profiles(res, prefix + "_profiles.png")
                if pp:
                    print("  wrote {}".format(pp))
    return results


if __name__ == "__main__":
    main()
