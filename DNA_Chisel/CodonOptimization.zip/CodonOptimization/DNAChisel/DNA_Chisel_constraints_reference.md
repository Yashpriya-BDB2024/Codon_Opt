# DNA Chisel constraints & objectives — reference for codon-optimization sweeps

*Catalogued against dnachisel 3.2.16 (installed and introspected directly). Covers every built-in `Specification` exported from the package, grouped by what it does for codon optimization, with the parameter ranges worth sweeping. Pairs with `codon_grid_search.py`.*

---

## How specifications work (the one mechanic that matters)

Every item below is a `Specification`. The same class is used two ways depending on where you put it:

- As a **constraint** (`constraints=[...]`) it is a hard pass/fail rule. The optimizer *must* satisfy it or it raises `NoSolutionError` — which the grid script catches and records as `FAILED`. Constraints are resolved first (`resolve_constraints()`).
- As an **objective** (`objectives=[...]`) it is a soft score the optimizer *maximizes* after constraints are met (`optimize()`), trading off against other objectives by their `boost` weight.

`EnforceTranslation` is the one you never omit: it pins the protein, so every other spec is free to rewrite the DNA underneath without changing the amino acids. Most specs accept a `boost` (objective weight) and a `location` (restrict to a sub-region); the grid applies them genome-wide and leaves `boost` at 1.0 unless noted.

A practical ordering when you reason about a variant: **integrity guards** keep it a valid CDS → **codon-usage** objectives make it express → **base-composition / repeat / structure** constraints make it synthesizable and clonable → **motif/site** removal keeps it clean → **specificity** checks (optional, external tools) keep it orthogonal.

---

## Group 1 — Sequence-integrity guards

These keep the edited DNA a legal, in-frame coding sequence. They rarely change expression on their own; they stop the optimizer from producing something broken. `EnforceTranslation` is always on in the grid; the rest are available for special cases.

| Spec | Role | What it guarantees |
|---|---|---|
| **`EnforceTranslation`** | constraint | The translated protein is unchanged. The anchor for all synonymous recoding. |
| **`AvoidStopCodons`** | constraint | No *new* stop codon in-frame — useful when editing a frame you don't translate end-to-end (e.g. fusion linkers). |
| **`SequenceLengthBounds`** | constraint (check only) | Length stays within `[min_length, max_length]`. Can't be "solved", only verified — handy as a guard in a mixed list. |
| **`AvoidChanges`** | constraint / objective | Freezes specified positions (`max_edits`, `location`/`indices`). Use to protect a signal peptide, a native restriction site you *want*, or a Kozak context from being recoded. |
| **`EnforceChanges`** | constraint / objective | The opposite — forces positions to differ from a reference (`minimum`, `minimum_percent`). Use to force diversity between variants or away from a parent. |
| **`EnforceSequence`** | constraint | Pins an exact or degenerate (IUPAC) subsequence at a location — e.g. keep a Kozak `GCCACCATGG` or an enforced tag. |
| **`EnforceChoice`** | constraint | The subsequence must be one of an explicit set of alternatives. |
| **`EnforcePatternOccurence`** | constraint | Forces a pattern to appear exactly *N* times — insert a needed site a set number of times, or trim supernumerary ones. |
| **`EnforceRegionsCompatibility`** | constraint | Enforces a pairwise condition across regions (e.g. all cloning overhangs mutually distinct). Advanced; for multi-part assemblies. |

---

## Group 2 — Codon usage & translation efficiency *(the expression levers)*

This is where yield actually moves. `CodonOptimize` is a dispatcher that returns one of three real specs by `method`; all are **objectives** and all require an `EnforceTranslation` constraint over the same region.

- **`CodonOptimize(method="use_best_codon")`** → wraps **`MaximizeCAI`**. Replaces every codon with the single most frequent synonymous codon in the host; maximizes CAI (score = *N*·log CAI). Highest predicted translation speed, but monotonous usage can over-draw a few tRNA pools and introduce repetitiveness — pair it with GC and k-mer constraints.
- **`CodonOptimize(method="match_codon_usage")`** → wraps **`MatchTargetCodonUsage`**. Makes the *distribution* of codons match the host's natural frequencies rather than always picking the best. Usually the safer default for secreted proteins and mAbs: good expression without the pathologies of pure CAI-maxing. (This is the baseline in the grid.)
- **`CodonOptimize(method="harmonize_rca")`** → wraps **`HarmonizeRCA`** (Claassens 2017). Preserves the *rhythm* of the native gene — rare-in-source codons map to rare-in-host codons — to protect co-translational folding. Needs `original_species`. Use when folding/solubility matters more than raw rate.
- **`AvoidRareCodons(min_frequency, species)`** — constraint. A "mild" optimization: leaves most codons alone but forbids any synonymous codon below a frequency cutoff, removing translational-pause hotspots. Combine with a codon objective, or use alone (`codon_method=None`) for a light-touch recode that stays close to the input.

**Species / tables.** Names resolve through `python_codon_tables`. Bundled offline: `h_sapiens`, `e_coli`, `s_cerevisiae`. Anything else (including **CHO / `cricetulus_griseus`, TaxID 10029**) is fetched from the web on first use, or supplied via `codon_usage_table=`. If your CLD target is CHO rather than human, set `species` accordingly and pre-cache the table, or point the script at a local table.

---

## Group 3 — Base composition

Keeps GC where the synthesis vendor and the expression host are happy, globally and locally.

- **`EnforceGCContent(mini, maxi, window, target)`** — the workhorse. As a **constraint** with `mini`/`maxi` (fractions 0–1) and a `window` (e.g. 50 nt), it bounds GC in *every* sliding window, which is what kills local GC-rich/AT-rich stretches that break synthesis — stricter and more useful than a global-only bound. With `target` instead, it becomes a soft **objective** pulling toward a GC setpoint. Leaving `window=None` bounds only global GC.
- **`EnforceTerminalGCContent(window_size, mini, maxi)`** — constraint on GC at the two ends only. Useful when the ends are primer-binding or assembly-overhang regions that need a GC floor/ceiling independent of the body.

---

## Group 4 — Repeats, secondary structure & synthesizability

Repeats and strong hairpins are the usual reasons a gene fails synthesis or drops in yield; these address them.

- **`UniquifyAllKmers(k)`** — constraint. Forbids any *k*-mer from occurring more than once (both strands by default). Removes direct and inverted repeats that cause synthesis dropout and recombination. Smaller `k` is stricter and harder to satisfy; vendors like GeneArt typically tolerate repeated 9-mers but not 10-mers, so `k≈10` is a sensible floor. (Note: for sequences with 3+ copies it may only resolve as an *objective*, not a hard constraint.)
- **`AvoidHairpins(stem_size, hairpin_window)`** — constraint. Removes hairpins per IDT's definition (a stem with a reverse-complement partner nearby). Reduces mRNA secondary structure near the 5′ end and eases synthesis. Defaults `stem_size=20`, `hairpin_window=200`.
- **`EnforceMeltingTemperature(mini, maxi, target)`** — constraint/objective on subsequence Tm. Mostly for primer/overhang design rather than whole-CDS work; include when a region doubles as a primer site.

---

## Group 5 — Motif & restriction-site removal

All handled by one spec, **`AvoidPattern`** (constraint), which takes several pattern grammars:

- **Homopolymers** via the `NxBase` shorthand — `"6xA"` forbids runs of 6+ A. Long runs cause polymerase slippage and synthesis errors; the grid sweeps the allowed run length and forbids `(max+1)x` for each base.
- **Sequence motifs**, IUPAC-aware — e.g. `"AWTAAA"` (poly-A signal, W=A/T), `"ATTTA"` (AU-rich/ARE destabilizing element), `"TATAAA"` (cryptic TATA). Removing these avoids premature polyadenylation, mRNA instability and spurious transcription.
- **Restriction / Type-IIS sites** via the `ENZYME_site` shorthand — `"BsaI_site"`, `"BsmBI_site"`, `"EcoRI_site"`, etc. Keeps the CDS compatible with Golden Gate / cloning by removing internal cutters. (All 13 defaults in the script resolve cleanly on 3.2.16.)

`EnforcePatternOccurence` (Group 1) is the inverse when you need to *add* a site rather than remove one.

---

## Group 6 — Specificity & orthogonality *(external tools, off by default)*

These need a binary installed and a reference index, so the grid leaves them off; reach for them when a sequence must not cross-react with a host genome or other parts.

- **`AvoidMatches(match_length, bowtie_index)`** — constraint. No match longer than *N* against a Bowtie index (e.g. the host genome). The package explicitly recommends this over the BLAST version. Requires **Bowtie**.
- **`AvoidBlastMatches(blast_db, ...)`** — constraint. Same idea via local NCBI **BLAST+**; slower, kept for back-compat.
- **`AvoidHeterodimerization(other_primers_sequences, tmax)`** — constraint. Stops a region from annealing to a given primer set. Multiplex-primer design.

---

## What the grid sweeps, and over what ranges

`codon_grid_search.py` exposes the axes below. Each is one key in the config's `grid`; a value of `null` means "don't add that spec for this variant", so `null` is itself a meaningful grid point (it isolates a constraint's effect).

| Axis (config key) | Spec driven | Default sweep | What moving it does |
|---|---|---|---|
| `codon_method` | `CodonOptimize` / none | `null`, `use_best_codon`, `match_codon_usage` | Expression strategy: none (light) → CAI-max → usage-match |
| `gc_min` | `EnforceGCContent` lower | `0.30, 0.40, 0.46` | Local GC floor (per window) |
| `gc_max` | `EnforceGCContent` upper | `0.60, 0.66, 0.70` | Local GC ceiling (per window) |
| `gc_window` | `EnforceGCContent` window | `50` | Window the GC bound is enforced over (`null` = global) |
| `gc_target` | `EnforceGCContent` objective | `null` | Optional soft GC setpoint instead of hard bounds |
| `kmer` | `UniquifyAllKmers` | `null, 9, 10, 15` | Repeat strictness; smaller = stricter |
| `rare_codon_min_freq` | `AvoidRareCodons` | `null, 0.11` | Rare-codon cutoff; higher = more codons forbidden |
| `homopolymer_max` | `AvoidPattern NxBase` | `4, 5, 6` | Longest allowed single-base run |
| `avoid_motifs` | `AvoidPattern` (motifs) | `true` | Toggle poly-A/ARE/TATA screening |
| `avoid_restriction_sites` | `AvoidPattern` (sites) | `true` | Toggle the 13-enzyme site screen |
| `avoid_hairpins` | `AvoidHairpins` | `false` | Toggle IDT-style hairpin removal |
| `tm_min` / `tm_max` | `EnforceMeltingTemperature` | `null` | Optional Tm window (primer-ish regions) |
| `terminal_gc_*` | `EnforceTerminalGCContent` | `null` | Optional end-GC bound |

The GC example from the brief ("30 to 70") maps to sweeping `gc_min` down to `0.30` and `gc_max` up to `0.70`; invalid pairs (`gc_min ≥ gc_max`) are pruned automatically.

**Metrics recorded per sequence × variant:** status, nucleotides changed, % identity, global GC, worst 50-nt-window GC (min & max), longest homopolymer, repeated 10-mers (fixed audit *k*, independent of the swept `kmer`), CAI vs species, codon-usage-match score, and surviving forbidden motifs. The `Summary` sheet averages these per variant across all input sequences, so you can read off which cutoffs help before committing to a synthesis order.

---

## Sweep modes

- **`--mode ofat`** (one-factor-at-a-time): baseline plus one changed axis per variant. ~15 variants from the default grid; the cleanest way to see each cutoff's isolated effect. Run this first.
- **`--mode cartesian`**: full product, pruned and de-duplicated, capped by `--max-variants` (seeded random sample if the product is larger). Use once OFAT has told you which axes and ranges are worth crossing.

---

## Licensing note

DNA Chisel is **MIT**-licensed and `python_codon_tables` is **MIT** — both fine for commercial use, no attribution burden beyond the license text. The Group 6 externals are separate installs under their own terms: **Bowtie** (Artistic/GPL) and **NCBI BLAST+** (public domain). Nothing in the default grid reaches outside the MIT core, so a standard commercial pipeline stays clean unless you deliberately enable `AvoidMatches` / `AvoidBlastMatches`.
