# `codon_grid_search.py` — how it works

*Companion documentation for the grid-search driver. Explains how the DNA Chisel optimization problem is assembled (constraints vs. objectives), how the grid is defined and expanded, how the host codon usage table is supplied as a file and wired into the package, and how species/domain handling works (including CHO). Written against dnachisel 3.2.16, all behaviour below verified by running the package directly.*

---

## 1. What the script does

For each input sequence (an in-frame CDS from the `Generated DNA Sequence` column), the script builds a set of **variants**. Each variant is one combination of optimization settings — a codon strategy plus a particular choice of GC bounds, k-mer uniqueness, rare-codon cutoff, homopolymer limit, and motif/site screens. Every variant is turned into a DNA Chisel `DnaOptimizationProblem`, solved, and scored on a battery of sequence metrics. The output Excel has three sheets: `Summary` (metrics averaged per variant across all sequences), `Results` (every sequence × variant row with its optimized sequence), and `Grid` (the exact settings behind each variant name).

The point is to replace hand-written variants with a *swept* parameter space, so you can see which cutoffs actually move the metrics before committing to a synthesis order.

### Input: DNA or protein

The input Excel needs a `Name` column and one sequence column, which may hold **either DNA or protein**:

- `--input-type dna` — the column is an in-frame CDS, used as-is.
- `--input-type protein` — the column is amino acids; each is **reverse-translated** to a starting DNA with `dnachisel.reverse_translate` (deterministic, Standard genetic table), and that DNA is then optimized and scored exactly like a DNA input.
- `--input-type auto` (default) — the type is detected per sequence from its alphabet: all-`ACGTN` and length divisible by 3 → DNA, otherwise protein.

The sequence column is auto-detected from common names (`Generated DNA Sequence`, `DNA Sequence`, `CDS`, … for DNA; `Protein Sequence`, `Protein`, `AA Sequence`, … for protein), or set explicitly with `--seq-col`. A trailing stop `*` on a protein is stripped; invalid residues/bases produce a clear per-row `INPUT ERROR` instead of crashing the run. Each output row carries an `Input kind` column recording how it was read.

One caveat for protein input: the reverse-translation seed is a *neutral* starting sequence, not a native gene, so for protein input the `Nucleotides changed` and `% identity` metrics measure divergence from that seed, not from any real wild-type CDS. CAI, GC, Tm, repeats and motif counts are properties of the final sequence and are unaffected by this.

---

## 2. How the optimization problem is set up

The core is `build_problem(sequence, params, table, motifs, sites)`, which converts one variant's parameter dict into a `DnaOptimizationProblem` (`table` is the loaded host codon usage dict; §4). DNA Chisel distinguishes two kinds of specification, and the split is the single most important thing to understand:

- **Constraints** (`constraints=[...]`) are hard pass/fail rules. The solver *must* satisfy all of them; if it cannot, it raises `NoSolutionError`.
- **Objectives** (`objectives=[...]`) are soft scores the solver *maximizes* after the constraints are already satisfied, trading off against one another by weight.

The problem is solved in two phases, which the script calls in order: `problem.resolve_constraints()` makes the sequence legal, then `problem.optimize()` improves the objectives without breaking any constraint. `problem.all_constraints_pass()` then confirms the result.

### What goes where, and why

`EnforceTranslation()` is **always** added as a constraint. It pins the protein, so every other specification is free to rewrite the DNA underneath without changing the amino acids. Nothing else in the script would be safe without it.

The **codon strategy** is the only *objective* in the default setup. When `codon_method` is set, the script adds `CodonOptimize(codon_usage_table=table, method=...)`. `CodonOptimize` is a dispatcher: `use_best_codon` maximizes CAI (every codon → the host's most frequent synonym), while `match_codon_usage` makes the codon *distribution* match the host's natural frequencies (the gentler default). When `codon_method` is `None`, no codon objective is added at all — useful for a light-touch recode driven only by the constraints (e.g. just removing rare codons and bad motifs).

Everything else is added as a **constraint**:

| Parameter | Specification added | Kind |
|---|---|---|
| `gc_min` / `gc_max` + `gc_window` | `EnforceGCContent(mini, maxi, window)` | hard GC band enforced over *every* sliding window |
| `gc_target` | `EnforceGCContent(target, window)` | soft GC objective (only if set) |
| `homopolymer_max` | `AvoidPattern("{max+1}x{base}")` for A/C/G/T | forbids runs longer than the limit |
| `kmer` | `UniquifyAllKmers(k)` | no k-mer may repeat (removes direct/inverted repeats) |
| `rare_codon_min_freq` | `AvoidRareCodons(min_frequency, codon_usage_table=table)` | forbids any codon below the frequency cutoff |
| `avoid_motifs` | `AvoidPattern(m)` for each motif | removes poly-A signal / ARE / TATA (IUPAC-aware) |
| `avoid_restriction_sites` | `AvoidPattern("{enzyme}_site")` | removes internal cutters (13 enzymes by default) |
| `avoid_hairpins` | `AvoidHairpins()` | removes IDT-style hairpins |
| `tm_min` / `tm_max` | `EnforceMeltingTemperature(mini, maxi)` | Tm band (optional, off by default) |
| `terminal_gc_*` | `EnforceTerminalGCContent(window_size, mini, maxi)` | end-GC band (optional, off by default) |

A parameter set to `None` means its specification is simply not added for that variant — so `None` is a meaningful grid point: it isolates the effect of leaving a constraint out.

### Failure handling

`run_variant()` wraps the whole thing. It re-seeds `np.random.seed(42)` before every variant so the random starting point is identical and runs are reproducible, then resolves and optimizes inside a `try/except`. An infeasible combination (e.g. an impossibly tight GC band) raises `NoSolutionError`; the script catches it and records `FAILED: <reason>` for that row instead of crashing the whole sweep. The original sequence is returned unchanged for a failed variant, and its metric columns are left blank.

---

## 3. The grid

### Structure

The search space is a single config dict (`DEFAULT_CONFIG` in the script, or a JSON file passed with `--config`). It has three parts:

- The **host codon table** everything optimizes toward is supplied with `--codon-table` (see §4), not in the config, and is *not* a grid axis.
- **`baseline`** — one value per axis. This is the anchor for OFAT mode and the fallback for any axis a variant doesn't override.
- **`grid`** — the axes to sweep, each a list of values to try.

The default grid:

| Axis | Default values swept | Drives |
|---|---|---|
| `codon_method` | `null`, `use_best_codon`, `match_codon_usage` | expression strategy (none / CAI-max / usage-match) |
| `gc_min` | `0.30, 0.40, 0.46` | local GC floor (per window) |
| `gc_max` | `0.60, 0.66, 0.70` | local GC ceiling (per window) |
| `gc_window` | `50` | window the GC band is enforced over |
| `kmer` | `null, 9, 10, 15` | repeat strictness (smaller = stricter) |
| `rare_codon_min_freq` | `null, 0.11` | rare-codon cutoff |
| `homopolymer_max` | `4, 5, 6` | longest allowed single-base run |
| `avoid_motifs` | `true` | motif screen on/off |
| `avoid_restriction_sites` | `true` | restriction-site screen on/off |
| `avoid_hairpins` | `false` | hairpin removal on/off |
| `tm` | `null`, `[30, 55, 65]` | terminal melting-temperature band (off, or 55–65 °C on 30-nt ends) |
| `terminal_gc` | `null`, `[30, 0.40, 0.60]` | terminal GC band (off, or 40–60 % on 30-nt ends) |

The GC example from the original request ("30 to 70") is exactly this: `gc_min` sweeps down to `0.30` and `gc_max` up to `0.70`.

**Grouped axes.** `tm` and `terminal_gc` are each a *single* axis whose value is either `null` (off) or a `[window, low, high]` triple, because their three numbers only make sense together — the window plus a low/high bound. `tm` is `[window_nt, Tm_min_°C, Tm_max_°C]`; `terminal_gc` is `[window_nt, GC_min_frac, GC_max_frac]`. In the output these are expanded back into explicit columns (`tm_window`/`tm_min`/`tm_max`, `terminal_gc_window`/`terminal_gc_min`/`terminal_gc_max`) so the sheet stays readable; a blank cell means that axis was off for the variant.

**Why Tm is scoped to the ends.** Melting temperature is only meaningful on a short, primer-scale region — the Tm of a whole 2 kb CDS is ~75 °C+ and uninformative. So the `tm` axis applies `EnforceMeltingTemperature` to the 5′ and 3′ terminal windows (the ends), never the whole sequence, parallel to how `EnforceTerminalGCContent` works. With the default 55–65 °C band it usually acts as a guard (CDS ends typically fall in range already); tighten or shift the band to make it actively drive end composition. An unreachable band simply fails that variant, which is informative.

### How variants are generated

Two modes, chosen with `--mode`:

- **`ofat`** (one-factor-at-a-time) — starts from the baseline, then produces one variant per *single* changed axis value. It answers "what does each cutoff do on its own?" with a small, clean set (~15 variants from the default grid). **Run this first.**
- **`cartesian`** — the full Cartesian product of all axis value-lists. This grows fast, so the script (a) prunes invalid combinations (`gc_min ≥ gc_max`, invalid Tm/terminal-GC bands), and (b) de-duplicates identical parameter sets. By default it then runs **every** remaining variant (`--max-variants 0`, the default); pass a positive `--max-variants N` to instead take a seeded random sample of N. With the default grid the full product is **2,592 variants per input sequence** (3 codon methods × 3 `gc_min` × 3 `gc_max` × 4 `kmer` × 2 `rare` × 3 `homopolymer_max` × 2 `tm` × 2 `terminal_gc`; the single-valued axes contribute ×1), none dropped since every `gc_min` is below every `gc_max`. Use it after OFAT has told you which axes are worth crossing — and note 2,592 variants × up to 4 solver attempts each is on the order of hours per sequence.

Each variant gets a readable name encoding how it differs from baseline — e.g. `V007_codonoff_gcmin0.4_gcmax0.6_hp4` is the variant with no codon objective, GC band 0.40–0.60, and homopolymers capped at 4; `V001_baseline` is the anchor. The `Grid` sheet in the output lists the full settings behind every name.

### Driving it from a file

`--dump-config default_grid.json` writes the current default config to JSON. Edit the `grid` lists (and `baseline`) there and pass it back with `--config my_grid.json` to run your own search space without touching the code.

---

## 4. The host codon usage table — a required file input

The host codon usage table is supplied as a **file** via `--codon-table`, and nothing else: there is no species name, no TaxID, no `python_codon_tables` lookup, no Kazusa download, and no cached or bundled table. You pass the exact table you have validated, so the run is fully deterministic and offline. `--codon-table` is required.

### Accepted formats (same loader as the codon-scoring scripts)

The loader mirrors the one in `codon_score.py` / `codon_features.py`, so a table that works there works here unchanged:

- **CSV / TSV** with columns `amino_acid, codon, fraction`. The value column may instead be named `frequency`, `freq`, `count`, `number`, or `proportion`; the `amino_acid` column is optional and is derived from the codon when absent. Codons may be written with U or T.
- **JSON**, either nested `{aa: {codon: value}}` or flat `{codon: value}`.

Whatever the raw values are (within-family fractions, per-1000 frequencies, or raw counts), the loader **normalises each amino-acid family to sum to 1.0** — which is precisely the dict shape DNA Chisel's `codon_usage_table` argument expects. CSV round-trips from a source table were verified bit-faithful (max per-codon difference 0.0 bar rounding).

### How it plugs into DNA Chisel

The normalised `{aa: {codon: fraction}}` dict is injected into **every** codon-aware specification through its `codon_usage_table=` argument — the `CodonOptimize` objective (both `use_best_codon` and `match_codon_usage`), the `AvoidRareCodons` constraint, and the two scoring metrics `MaximizeCAI` (CAI) and `MatchTargetCodonUsage` (codon-match score). One table therefore drives optimization and scoring identically; all four were confirmed to accept a hand-built table dict. The table is loaded once per run and reused across every variant and sequence. If the table is missing an amino-acid family, the run warns up front (sequences needing that residue would otherwise fail). The resolved host label (the file stem, or `--host-label`) and the domain are written into every output row for provenance.

Species is deliberately **not** a grid axis: a sequence is optimized for one host, and sweeping it would mix incomparable CAI/usage scores into one table.

### CHO

Build a *Cricetulus griseus* table once from **CoCoPUTs** (or, for higher fidelity, from a high-expression CHO transcriptome subset), save it as a CSV in the `amino_acid,codon,fraction` layout, keep it under version control, and pass it with `--codon-table`. This is the same CHO table you build for the scoring scripts — reuse that file directly. Example:

```bash
python codon_grid_search.py --input genes.xlsx --output cho_grid.xlsx \
    --codon-table cho_cocoputs.csv --domain eukaryote --mode ofat --limit 1   # quick check
python codon_grid_search.py --input genes.xlsx --output cho_grid.xlsx \
    --codon-table cho_cocoputs.csv --domain eukaryote                         # full sweep
```

---

## 5. Species handling: fixed grid, domain-specific motifs

The grid and every numeric parameter (GC bounds, k-mer, rare-codon cutoff, homopolymer, Tm, terminal GC, codon strategy) are **identical for all species**. Species differences enter only two ways:

1. **The codon table you supply** (§4) — this carries all the quantitative species specificity into codon choice, CAI, rare-codon avoidance, and the usage-match score.
2. **The `--domain` flag** — which selects the species-/domain-specific *motif* screen, the one place where the right sequence liabilities differ between kingdoms:
   - `--domain eukaryote` (default): `AWTAAA` (poly-A signal, W=A/T), `ATTTA` (AU-rich/ARE destabilising element), `TATAAA` (cryptic TATA box). Right for CHO, human, and other eukaryotic hosts.
   - `--domain prokaryote`: `AGGAGG` (internal Shine-Dalgarno / ribosome-binding core). Removing it avoids spurious internal translation initiation and ribosome pausing in *E. coli*-type hosts; the eukaryotic poly-A/ARE/TATA signals don't apply there. Verified to drop an internal `AGGAGG` from a seed to zero.

Restriction-site, GC, k-mer, homopolymer and Tm handling are shared across both domains. You can still override the motif list entirely with a `motifs` key in a `--config` JSON if you want a custom screen.

---

## 6. Metrics recorded per sequence × variant

`host` (table label) and `domain`, `status`, `seed used` (which seed produced the result — see retries below), `input kind` (dna / protein), `objective score`, `runtime`, the full variant definition (every axis value, grouped axes expanded), then: nucleotides changed, % identity (to the input DNA, or to the reverse-translation seed for protein input), global GC%, worst-case GC% over 50-nt windows (min and max — this catches local GC trouble a global number hides), longest homopolymer run, number of repeated 10-mers (a fixed audit *k*, independent of the swept `kmer` so it's comparable across variants), **CAI** vs the supplied host table, **codon-match score** (closer to 0 = usage matches the host table), **5′ and 3′ terminal Tm** (°C over a 30-nt window), and surviving forbidden motifs. The `Summary` sheet averages these per variant across all input sequences and reports how many sequences passed all constraints (`n_passed`).

### Retries on solver dead-ends

DNA Chisel's constraint resolver uses randomized local search, so a hard combination can dead-end on one random start yet succeed on another — occasionally a *looser* variant fails where the stricter baseline passed, purely by luck of the search path. The runner therefore tries the primary `--seed` first (reproducible), then up to `--retries` fallback seeds (default 3, derived deterministically from `--seed`) before recording `FAILED`. The `Seed used` column shows which seed actually produced each row, so results stay reproducible. Set `--retries 0` to disable.

---

## 7. Command reference

```bash
# write the default search space to edit
python codon_grid_search.py --dump-config default_grid.json

# one-factor-at-a-time, one gene (fast sanity check)
python codon_grid_search.py --input genes.xlsx --output ofat.xlsx \
    --codon-table human.csv --mode ofat --limit 1

# full eukaryote sweep (all 2,592 variants per sequence by default)
python codon_grid_search.py --input genes.xlsx --output grid.xlsx \
    --codon-table cho_cocoputs.csv --domain eukaryote --mode cartesian

# PROTEIN input (reverse-translated, then optimized), naming the column explicitly
python codon_grid_search.py --input proteins.xlsx --output prot.xlsx \
    --codon-table cho_cocoputs.csv --input-type protein --seq-col "Protein Sequence"

# prokaryote host (E. coli): Shine-Dalgarno motif screen
python codon_grid_search.py --input genes.xlsx --output ecoli.xlsx \
    --codon-table ecoli.csv --domain prokaryote

# cap a cartesian run to a random sample (e.g. a quick 300-variant look)
python codon_grid_search.py --input genes.xlsx --output sample.xlsx \
    --codon-table human.csv --mode cartesian --max-variants 300

# drive a custom search space from JSON
python codon_grid_search.py --input genes.xlsx --output grid.xlsx \
    --config my_grid.json
```

`--codon-table FILE` is **required** (CSV/TSV or JSON; §4). The input needs a `Name` column and one sequence column (DNA or protein; auto-detected, or set with `--seq-col` / `--input-type`). `--domain` picks the eukaryote/prokaryote motif screen; `--host-label` labels the host in the output. `--limit N` runs only the first N sequences. `--seed` controls the cartesian sampling and the primary optimization seed; `--retries` sets how many fallback seeds to try on a solver dead-end.

---

## 8. Licensing

DNA Chisel is MIT and clear for commercial use. The script no longer depends on `python_codon_tables` or any download — you supply the codon table file, so there is no runtime network dependency and no third-party table-licensing question in the optimization path; the provenance and licensing of the table you supply (e.g. a CoCoPUTs-derived CHO table) are whatever you have cleared for that source. Nothing in the default grid reaches any GPL/Artistic dependency — those only appear if you deliberately enable `AvoidMatches` (Bowtie) or `AvoidBlastMatches` (NCBI BLAST+), which are off by default.
