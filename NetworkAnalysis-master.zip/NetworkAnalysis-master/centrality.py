#import
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx
from collections import defaultdict

#function for finding shortest path
def centrality(par_file):
    #extracting the parameters
    with open(par_file, 'r') as f:
        lines = f.readlines()
    if len(lines) != 3:
        print("Give three input")
        return
    graph = lines[0].strip()
    nodes = lines[1].strip()
    weighted = lines[2].strip()
    
    #Constructing a network
    edge = pd.read_csv(graph,sep='\t')
    if weighted == "YES":
        #inverse the weight - for correct representation of signal
        a = edge['weight']
        a = 1/a
        edge['weight'] = a
    
    #creating a network with the edge list file
    G = nx.from_pandas_edgelist(edge, source='source', target='target', edge_attr=True)
    #ploting the network
    nx.draw_networkx(G, pos=nx.circular_layout(G), with_labels=True, font_weight='bold') 
    edge_weight = nx.get_edge_attributes(G,'weight')
    nx.draw_networkx_edge_labels(G, pos=nx.circular_layout(G), edge_labels = edge_weight)
    #Finding degree centrality
    deg_centrality = nx.degree_centrality(G)
    if weighted == "YES":
        #Finding betweeness centrality
        bet_centrality = nx.betweenness_centrality(G, normalized = True, endpoints = False, weight='weight') #weight=None if unweighted
        #Finding closeness centrality
        close_centrality = nx.closeness_centrality(G, distance = 'weight',wf_improved= True) #distance=None by default which assumes all edge weight as 1
        #finding clustering coefficient
        clustering_coeff = nx.clustering(G, nodes=None, weight='weight') #weight=None if unweighted
        
    else:
        #Finding betweeness centrality
        bet_centrality = nx.betweenness_centrality(G, normalized = True, endpoints = False, weight= None)
        #Finding closeness centrality
        close_centrality = nx.closeness_centrality(G,wf_improved= True)
        #finding clustering coefficient
        clustering_coeff = nx.clustering(G, nodes=None, weight= None)

    #writing the centrality measures to a file
    merge_measures = defaultdict(list) #setting the value corresponding to the key to store a list
    line = []
    #cleaning node names of any white spaces
    with open(nodes,'r') as file:
        for l in file:
            l = l.strip()
            line.append(l)
        keys = line
    for i in keys:
        if weighted == "YES":
            #find neighbor and sum edge weight
            fn = list(G.neighbors(i))
            edge_w = []
            for n in fn:
                w = G[i][n]["weight"]
                w = 1/w
                edge_w.append(w)
            deg = sum(edge_w) #for weighted
        else:
            deg = G.degree[i] #for unweighted
        data = [clustering_coeff[i],deg_centrality[i], deg , close_centrality[i],bet_centrality[i]] #making a list to append
        merge_measures[i].append(data)
    with open("centrality_measures.txt", 'w') as f: 
        f.write('Node\tclustering_coefficient\tdegree_centrality\tdegree\tcloseness_centrality\tbetweenness_centrality\n')
        for key, value in merge_measures.items():
            f.write(('%s,%s\n' % (key, ('%s'%(value)).strip("[]"))).replace(',','\t')) #clearing the list and making it tab seperated
        
        
    
#getting arguments and calling the function
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Provide a parameter file")
        sys.exit(1)
    par_file = sys.argv[1]
    centrality(par_file)