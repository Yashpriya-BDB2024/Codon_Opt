#imports
import pickle
import random
import logging
import pandas as pd
import numpy as np
import networkx as nx
from typing import Set, List, Tuple, Dict, Optional

#Logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('drug_synergy_analysis.log'),
        logging.StreamHandler()])
logger = logging.getLogger(__name__)

class NetworkProximityAnalyzer:
    def __init__(self):
        self.shortest_paths = None
        
    #Network
    def load_shortest_paths(self, cache_file: str) -> Dict:
        """
        Load precomputed shortest paths from file
        """
        logger.info(f"Loading precomputed shortest paths from {cache_file}...")
        try:
            with open(cache_file, 'rb') as f:
                self.shortest_paths = pickle.load(f)
            logger.info(f"Loaded shortest paths for {len(self.shortest_paths)} nodes")
            return self.shortest_paths
        except Exception as e:
            logger.error(f"Failed to load shortest paths: {e}")
            raise
    
    def get_network_nodes(self) -> Set[str]:
        """
        Get all nodes in the network from shortest paths data
        """
        return set(self.shortest_paths.keys())
    
    def get_degree_binning(self, min_bin_size: int = 100) -> List[Tuple[int, int, List[str]]]:
        """
        Bin nodes by degree for degree-preserving randomization
        Uses the shortest paths data to calculate degrees
        """
        #Calculate degrees from shortest paths
        degrees = {}
        for node, connections in self.shortest_paths.items():
            direct_neighbors = [n for n, dist in connections.items() if dist == 0.0]
            degrees[node] = len(direct_neighbors)
        degree_to_nodes = {}
        for node, degree in degrees.items():
            degree_to_nodes.setdefault(degree, []).append(node)
        
        values = sorted(degree_to_nodes.keys())
        bins = []
        i = 0
        
        while i < len(values):
            low = values[i]
            val = degree_to_nodes[values[i]].copy()
            while len(val) < min_bin_size and i < len(values) - 1:
                i += 1
                val.extend(degree_to_nodes[values[i]])
            high = values[i]
            i += 1
            if len(val) < min_bin_size and bins:
                low_prev, high_prev, val_prev = bins[-1]
                bins[-1] = (low_prev, high, val_prev + val)
            else:
                bins.append((low, high, val))
        return bins
    
    def get_degree_equivalents(self, nodes: Set[str], bins: List[Tuple[int, int, List[str]]]) -> Dict[str, List[str]]:
        """
        Find degree-equivalent nodes for randomization
        """
        #Calculate degrees from shortest paths
        degrees = {}
        for node in nodes:
            if node in self.shortest_paths:
                direct_neighbors = [n for n, dist in self.shortest_paths[node].items() if dist == 0.0]
                degrees[node] = len(direct_neighbors)
            else:
                degrees[node] = 0
        node_to_equivalents = {}
        for node in nodes:
            d = degrees[node]
            for low, high, bin_nodes in bins:
                if low <= d <= high:
                    equivalents = [n for n in bin_nodes if n != node]
                    node_to_equivalents[node] = equivalents
                    break
        return node_to_equivalents
    
    def get_random_nodes_matching_degree(self, original_nodes: Set[str], n_random: int = 1000, min_bin_size: int = 100, seed: Optional[int] = None) -> List[Set[str]]:
        """
        Generate random node sets with degree distribution matching original nodes
        """
        if seed is not None:
            random.seed(seed)
        bins = self.get_degree_binning(min_bin_size)
        node_to_equivalents = self.get_degree_equivalents(original_nodes, bins)
        random_sets = []
        network_nodes = self.get_network_nodes()
        for _ in range(n_random):
            random_set = set()
            for node in original_nodes:
                if node in node_to_equivalents and node_to_equivalents[node]:
                    equivalent = random.choice(node_to_equivalents[node])
                    random_set.add(equivalent)
                else:
                    #Fallback: random node from network
                    random_set.add(random.choice(list(network_nodes)))
            random_sets.append(random_set)
        return random_sets
    
    #Proximity
    def calculate_closest_distance(self, set_a: Set[str], set_b: Set[str]) -> float:
        """
        Calculate mean closest distance between two sets of nodes using precomputed paths
        """
        distances = []
        for node_a in set_a:
            if node_a not in self.shortest_paths:
                continue
                
            min_dist = float('inf')
            for node_b in set_b:
                if node_b in self.shortest_paths[node_a]:
                    dist = self.shortest_paths[node_a][node_b]
                    if dist < min_dist:
                        min_dist = dist
            
            if min_dist != float('inf'):
                distances.append(min_dist)
        return np.mean(distances) if distances else float('inf')
    
    def calculate_proximity(self, drug_targets: Set[str], disease_genes: Set[str], n_random: int = 1000, min_bin_size: int = 100,seed: Optional[int] = None) -> Tuple[float, float, float, float]:
        """
        Calculate drug-disease proximity (z-score)
        Returns: (z_score, actual_distance, mean_random, std_random)
        """
        #Filter nodes that exist in network
        network_nodes = self.get_network_nodes()
        drug_targets = drug_targets & network_nodes
        disease_genes = disease_genes & network_nodes
        
        if not drug_targets or not disease_genes:
            raise ValueError("No overlapping nodes between input sets and network")
        
        #Calculate actual distance
        actual_distance = self.calculate_closest_distance(drug_targets, disease_genes)
        
        #Generate random sets
        random_drug_sets = self.get_random_nodes_matching_degree(drug_targets, n_random, min_bin_size, seed)
        random_disease_sets = self.get_random_nodes_matching_degree(disease_genes, n_random, min_bin_size, seed)
        
        #Calculate random distances
        random_distances = []
        for rand_drugs, rand_diseases in zip(random_drug_sets, random_disease_sets):
            dist = self.calculate_closest_distance(rand_drugs, rand_diseases)
            if dist != float('inf'):
                random_distances.append(dist)
        
        #Calculate z-score
        mean_random = np.mean(random_distances)
        std_random = np.std(random_distances)
        
        if std_random == 0:
            z_score = 0.0
        else:
            z_score = (actual_distance - mean_random) / std_random
        return z_score, actual_distance, mean_random, std_random
    
    def calculate_separation(self, set_a: Set[str], set_b: Set[str]) -> float:
        """
        Calculate separation score between two sets of nodes (s_AB)
        s_AB = <d_AB> - (<d_AA> + <d_BB>) / 2
        """
        #Calculate d_AA (within set A)
        d_aa = self.calculate_within_set_distance(set_a)
        
        #Calculate d_BB (within set B)
        d_bb = self.calculate_within_set_distance(set_b)
        
        #Calculate d_AB (between sets A and B)
        d_ab = self.calculate_between_set_distance(set_a, set_b)
        separation = d_ab - (d_aa + d_bb) / 2.0
        return separation
    
    def calculate_within_set_distance(self, node_set: Set[str]) -> float:
        """
        Calculate mean closest distance within a set of nodes
        """
        if len(node_set) <= 1:
            return 0.0
        
        distances = []
        nodes_list = list(node_set)
        
        for i, node_a in enumerate(nodes_list):
            if node_a not in self.shortest_paths:
                continue
                
            min_dist = float('inf')
            for j, node_b in enumerate(nodes_list):
                if i != j and node_b in self.shortest_paths[node_a]:
                    dist = self.shortest_paths[node_a][node_b]
                    if dist < min_dist:
                        min_dist = dist
            
            if min_dist != float('inf'):
                distances.append(min_dist)
        return np.mean(distances) if distances else float('inf')
    
    def calculate_between_set_distance(self, set_a: Set[str], set_b: Set[str]) -> float:
        """
        Calculate mean closest distance between two sets of nodes
        """
        distances_ab = []
        
        #From A to B
        for node_a in set_a:
            if node_a not in self.shortest_paths:
                continue
                
            min_dist = float('inf')
            for node_b in set_b:
                if node_b in self.shortest_paths[node_a]:
                    dist = self.shortest_paths[node_a][node_b]
                    if dist < min_dist:
                        min_dist = dist
            
            if min_dist != float('inf'):
                distances_ab.append(min_dist)
        
        #From B to A
        for node_b in set_b:
            if node_b not in self.shortest_paths:
                continue
                
            min_dist = float('inf')
            for node_a in set_a:
                if node_a in self.shortest_paths[node_b]:
                    dist = self.shortest_paths[node_b][node_a]
                    if dist < min_dist:
                        min_dist = dist
            
            if min_dist != float('inf'):
                distances_ab.append(min_dist)
        
        return np.mean(distances_ab) if distances_ab else float('inf')
    
    #Significance
    def calculate_empirical_p_value(self, actual_distance: float, drug_targets: Set[str],  disease_genes: Set[str], n_random: int = 1000) -> float:
        """
        Calculate empirical p-value for drug-disease proximity
        """
        random_distances = []
        
        #Generate random distances
        random_drug_sets = self.get_random_nodes_matching_degree(drug_targets, n_random)
        random_disease_sets = self.get_random_nodes_matching_degree(disease_genes, n_random)
        
        for rand_drugs, rand_diseases in zip(random_drug_sets, random_disease_sets):
            dist = self.calculate_closest_distance(rand_drugs, rand_diseases)
            if dist != float('inf'):
                random_distances.append(dist)
        
        p_value = np.mean(np.array(random_distances) <= actual_distance)

        return p_value
    
    def calculate_separation_p_value(self, set_a: Set[str], set_b: Set[str], actual_separation: float, n_random: int = 1000) -> float:
        """
        Calculate empirical p-value for drug-drug separation
        """
        random_separations = []
        
        #Generate random separation scores
        random_sets_a = self.get_random_nodes_matching_degree(set_a, n_random)
        random_sets_b = self.get_random_nodes_matching_degree(set_b, n_random)
        
        for rand_a, rand_b in zip(random_sets_a, random_sets_b):
            separation = self.calculate_separation(rand_a, rand_b)
            if separation != float('inf'):
                random_separations.append(separation)
        
        #For separation: more negative values are significant for overlap (s_AB < 0)
        #More positive values are significant for separation (s_AB > 0)
        if actual_separation < 0:  #Overlap case
            p_value = np.mean(np.array(random_separations) <= actual_separation)
        else:  #Separation case
            p_value = np.mean(np.array(random_separations) >= actual_separation)
        
        return p_value
    
    
    #Main
    def classify_drug_combination_with_confidence(self, drug_a_targets: Set[str], drug_b_targets: Set[str], disease_genes: Set[str], n_random: int = 1000, z_threshold: float = 0.0, alpha: float = 0.05) -> Dict:
        """
        Classify drug combination with statistical confidence metrics
        Returns dictionary with classification, p-values, and confidence indicators
        """
        #Calculate drug-disease proximities with p-values
        z_da, actual_da, _, _ = self.calculate_proximity(drug_a_targets, disease_genes, n_random)
        z_db, actual_db, _, _ = self.calculate_proximity(drug_b_targets, disease_genes, n_random)
        
        #Calculate empirical p-values for drug-disease proximity
        p_da = self.calculate_empirical_p_value(actual_da, drug_a_targets, disease_genes, n_random)
        p_db = self.calculate_empirical_p_value(actual_db, drug_b_targets, disease_genes, n_random)
        
        #Calculate drug-drug separation with p-value
        s_ab = self.calculate_separation(drug_a_targets, drug_b_targets)
        p_separation = self.calculate_separation_p_value(drug_a_targets, drug_b_targets, s_ab, n_random)
        
        #Determine significance
        drug_a_significant = p_da < alpha
        drug_b_significant = p_db < alpha
        separation_significant = p_separation < alpha
        
        # etermine the three binary conditions
        drug_a_hits_disease = z_da < z_threshold
        drug_b_hits_disease = z_db < z_threshold
        drugs_overlap = s_ab < 0

        logger.info(f"Proximity of drug A - Z score: {z_da:.4f}, pvalue: {p_da}")
        logger.info(f"Proximity of drug B - Z score: {z_db:.4f}, pvalue: {p_db}")
        logger.info(f"Separation between drug A & drug B - Sab score: {s_ab:.4f}, P value: {p_separation:.4e}")
        
        #Classify based on the combination of conditions
        if drug_a_hits_disease and drug_b_hits_disease:
            if drug_a_significant and drug_b_significant:
                logger.info("Significant- Both drug targets in proximity with the disease module")
                if drugs_overlap:
                    if separation_significant:
                        classification = "Significant Overlapping Exposure"
                    else:
                        classification = "Overlapping Exposure but not significant"
                else:
                    if separation_significant:
                        classification = "Significant Complementary Exposure"
                    else:
                        classification = "Complementary Exposure but not significant"
            else:
                logger.info("Not Significant- Both drug targets in proximity with the disease module")
                if drugs_overlap:
                    if separation_significant:
                        classification = "Significant Overlapping Exposure"
                    else:
                        classification = "Overlapping Exposure but not significant"
                else:
                    if separation_significant:
                        classification = "Significant Complementary Exposure"
                    else:
                        classification = "Complementary Exposure but not significant"
        
        elif drug_a_hits_disease and not drug_b_hits_disease:
            if drug_a_significant and drug_b_significant:
                logger.info("Significant- Only drug target A in proximity with the disease module")
                if drugs_overlap:
                    if separation_significant:
                        classification = "Significant Indirect Exposure"
                    else:
                        classification = "Indirect Exposure but not significant"
                else:
                    if separation_significant:
                        classification = "Significant Single Exposure"
                    else:
                        classification = "Single Exposure but not significant"
            else:
                logger.info("Not Significant- Only drug target A in proximity with the disease module")
                if drugs_overlap:
                    if separation_significant:
                        classification = "Significant Indirect Exposure"
                    else:
                        classification = "Indirect Exposure but not significant"
                else:
                    if separation_significant:
                        classification = "Significant Single Exposure"
                    else:
                        classification = "Single Exposure but not significant"
  
        elif not drug_a_hits_disease and drug_b_hits_disease:
            if drug_a_significant and drug_b_significant:
                logger.info("Significant- Only drug target B in proximity with the disease module")
                if drugs_overlap:
                    if separation_significant:
                        classification = "Significant Indirect Exposure"
                    else:
                        classification = "Indirect Exposure but not significant"
                else:
                    if separation_significant:
                        classification = "Significant Single Exposure"
                    else:
                        classification = "Single Exposure but not significant"
            else:
                logger.info("Not Significant- Only drug target B in proximity with the disease module")
                if drugs_overlap:
                    if separation_significant:
                        classification = "Significant Indirect Exposure"
                    else:
                        classification = "Indirect Exposure but not significant"
                else:
                    if separation_significant:
                        classification = "Significant Single Exposure"
                    else:
                        classification = "Single Exposure but not significant"
        
        else:
            if drug_a_significant and drug_b_significant:
                logger.info("Significant- None of the drug target in proximity with the disease module")
                if drugs_overlap:
                    if separation_significant:
                        classification = "Significant Non-exposure"
                    else:
                        classification = "Non-exposure but not significant"
                else:
                    if separation_significant:
                        classification = "Significant Independent Action"
                    else:
                        classification = "Independent Action but not significant"
            else:
                logger.info("Not Significant- None of the drug target in proximity with the disease module")
                if drugs_overlap:
                    if separation_significant:
                        classification = "Significant Non-exposure"
                    else:
                        classification = "Non-exposure but not significant"
                else:
                    if separation_significant:
                        classification = "Significant Independent Action"
                    else:
                        classification = "Independent Action but not significant"
        
        #Return all metrics in a dictionary
        return {
            "classification": classification,
            "z_da": z_da,
            "pvalue_da":p_da,
            "z_db": z_db,
            "pvalue_db":p_db,
            "s_ab": s_ab,
            "p_separation": p_separation,
            "drug_a_significant": drug_a_significant,
            "drug_b_significant": drug_b_significant,
            "separation_significant": separation_significant
        }


def validate_moduleprotein(module, string):
    not_string = []
    for i in module:
        if i not in string.source.values and i not in string.target.values:
            not_string.append(i)
    if len(not_string) > 0:
        logger.warning(f"{len(not_string)} out of {len(module)} proteins in the disease module are not in string")

def validate_targetprotein(drug_targets, string):
    not_string = []
    for i in drug_targets:
        if i not in string.source.values and i not in string.target.values:
            not_string.append(i)
    if len(not_string) > 0:
        logger.warning(f"{len(not_string)} out of {len(drug_targets)} drug targets are not in string!")


# Main function
def main():
    logger.info("Starting drug synergy analysis")
    
    try:
        analyzer = NetworkProximityAnalyzer()
        analyzer.load_shortest_paths("shortest_paths_cache.pkl")
        
        logger.info("Loading STRING PPI network")
        string = pd.read_csv("STRING_PPI_filtered.txt", sep="\t")
        G = nx.from_pandas_edgelist(string, source='source', target='target', edge_attr=True)
        
        logger.info("Loading drug target data")
        combination = pd.read_excel('Drug_target.xlsx', sheet_name='Drug_combination')
        modules = pd.read_excel('Drug_target.xlsx', sheet_name='Module_genes')
        
        # Create a list to store results
        results = []
        
        for module in modules:
            logger.info("=" * 50)
            logger.info(f"Running proximity analysis for {module}")
            protein = modules[module].dropna().to_list()
            validate_moduleprotein(protein, string)
            
            module_combinations = combination[combination["Disease"] == module]
            if module_combinations.empty:
                logger.warning(f"No drug combinations found for disease: {module}")
                continue
                
            for index, row in module_combinations.iterrows():
                drugA = row["Drug_target1"].strip().split(",")
                drugB = row["Drug_target2"].strip().split(",")
                logger.info(f"Running combination: {drugA} + {drugB}")
                
                seed_genes = []
                seed_genes.extend(drugA)
                seed_genes.extend(drugB)
                validate_targetprotein(seed_genes, string)
                
                clusters = {}
                for i, seed_gene in enumerate(seed_genes):
                    if seed_gene in G:
                        clusters[seed_gene] = {
                            'nodes': [seed_gene] + [n for n in G.neighbors(seed_gene) if n in G],
                            'name': f'Cluster {i+1} ({seed_gene})'
                        }
                    else:
                        logger.warning(f"Seed gene {seed_gene} not found in network")
                        clusters[seed_gene] = {'nodes': [], 'name': f'Cluster {i+1} ({seed_gene})'}
                
                drug_a_targets = []
                drug_b_targets = []
                for i in drugA:
                    drug_a_targets.extend(clusters[i]["nodes"])
                for i in drugB:
                    drug_b_targets.extend(clusters[i]["nodes"])

                drug_a_targets = set(drug_a_targets)
                drug_b_targets = set(drug_b_targets)
                disease_genes = set(protein)
                
                try:
                    result = analyzer.classify_drug_combination_with_confidence(drug_a_targets, drug_b_targets, disease_genes, n_random=1000, alpha=0.05)
                    
                    results.append({
                        "Disease": module,
                        "Drug_target1": row["Drug_target1"],
                        "Drug_target2": row["Drug_target2"],
                        "Z_score_drugA": result["z_da"],
                        #"Pvalue_drugA":result["pvalue_da"],
                        "Z_score_drugB": result["z_db"],
                        #"Pvalue_drugB":result["pvalue_db"],
                        "Sab_score": result["s_ab"],
                        "P_value_separation": result["p_separation"],
                        "Classification": result["classification"]})
                    logger.info(f"Classification: {result['classification']}")
                except Exception as e:
                    logger.error(f"Error processing combination {drugA} + {drugB} for {module}: {e}")
                    results.append({
                        "Disease": module,
                        "Drug_target1": row["Drug_target1"],
                        "Drug_target2": row["Drug_target2"],
                        "Z_score_drugA": "ERROR",
                        #"Pvalue_drugA": "NA",
                        "Z_score_drugB": "ERROR",
                        #"Pvalue_drugB":"NA",
                        "Sab_score": "ERROR",
                        "P_value_separation": "ERROR",
                        "Classification": f"Error: {str(e)}"})
        
        results_df = pd.DataFrame(results)
        results_df.to_csv("Drug_combination_results.csv", index=False)
        logger.info(f"Results saved to Drug_combination_results.csv with {len(results_df)} records")

        successful_runs = len([r for r in results if r["Classification"] not in results_df.columns and "Error" not in r["Classification"]])
        errors = len(results) - successful_runs
        logger.info(f"Analysis completed: {successful_runs} successful runs, {errors} errors")
    except Exception as e:
        logger.error(f"Fatal error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()