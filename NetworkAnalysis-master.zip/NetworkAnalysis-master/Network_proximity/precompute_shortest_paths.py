#imports
import networkx as nx
import pandas as pd
import pickle
from typing import Dict
from tqdm import tqdm

def precompute_shortest_paths(tsv_file: str, output_file: str, weight_default: float = 0.0) -> Dict:
    print(f"Loading network from {tsv_file}...")
    df = pd.read_csv(tsv_file, sep='\t')
    network = nx.Graph()
    for _, row in df.iterrows():
        source = str(row['source'])
        target = str(row['target'])
        if 'Weight' in row and not pd.isna(row['Weight']):
            weight = float(row['Weight'])
        else:
            weight = weight_default
        network.add_edge(source, target, weight=weight)
    print(f"Network loaded: {network.number_of_nodes()} nodes, {network.number_of_edges()} edges")
    print("Calculating shortest paths...")
    
    shortest_paths = {}
    nodes = list(network.nodes())
    for source in tqdm(nodes, desc="Shortest paths progress"):
        lengths = nx.single_source_dijkstra_path_length(network, source)
        shortest_paths[source] = lengths

    with open(output_file, 'wb') as f:
        pickle.dump(shortest_paths, f)
    print(f"Shortest paths computed and saved to {output_file}")
    return shortest_paths

if __name__ == "__main__":
    shortest_paths = precompute_shortest_paths(tsv_file="STRING_PPI_filtered.txt",output_file="shortest_paths_cache.pkl",weight_default=0.0)