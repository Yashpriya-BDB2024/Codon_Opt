#imports
from bs4 import BeautifulSoup
import pandas as pd

#input KEGG files, make sure the files are in the same location
kegg_pathways = ["hsa04060.xml","hsa04630.xml","hsa05224.xml","hsa04657.xml","hsa04658.xml","hsa04659.xml"]

nodes = pd.DataFrame(columns=["hsa-id","type"])
for file in kegg_pathways:
    f = open(file,"r")
    soup = BeautifulSoup(f,features="xml")
    for i in soup.find_all("entry"):
        final_list=[]
        if i.get("type") != "map":
            nodes = pd.concat([nodes, pd.DataFrame({"hsa-id":i.get("name"),"type":i.get("type")}, index=[0])], ignore_index=True)

nodes = nodes.loc[nodes["type"]=="gene"]
nodes["hsa-id"] = nodes["hsa-id"].str.split(" ")
nodes.explode("hsa-id")["hsa-id"].to_csv("KEGG_geneids.csv",index=False) #hsa IDs needs to be mapped with the HGNC symbol, use https://www.uniprot.org/id-mapping