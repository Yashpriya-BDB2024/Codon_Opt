#import
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx
from collections import defaultdict

#function for finding shortest path
def find_hub(par_file):
    #extracting the parameters
    with open(par_file, 'r') as f:
        lines = f.readlines()
    if len(lines) != 3:
        print("Give three input")
        return
    graph = lines[0].strip()
    percent = float(lines[1])
    weighted = lines[2].strip()
    
    #Constructing a network
    edge = pd.read_csv(graph,sep='\t')
    if weighted == "YES":
        #inverse the weight - for correct representation of signal
        a = edge['weight']
        a = 1/a
        edge['weight'] = a
    
    #creating a network with the edge list file
    G = nx.from_pandas_edgelist(edge, source='source', target='target', edge_attr=True)
    #ploting the network
    nx.draw_networkx(G, pos=nx.circular_layout(G), with_labels=True, font_weight='bold') 
    edge_weight = nx.get_edge_attributes(G,'weight')
    nx.draw_networkx_edge_labels(G, pos=nx.circular_layout(G), edge_labels = edge_weight)
    #Finding degree centrality
    deg_centrality = nx.degree_centrality(G)
    if weighted == "YES":
        #Finding betweeness centrality
        bet_centrality = nx.betweenness_centrality(G, normalized = True, endpoints = False, weight='weight') #weight=None if unweighted
        #Finding closeness centrality
        close_centrality = nx.closeness_centrality(G, distance = 'weight') #distance=None by default which assumes all edge weight as 1
        #finding clustering coefficient
        clustering_coeff = nx.clustering(G, nodes=None, weight='weight') #weight=None if unweighted
    else:
        #Finding betweeness centrality
        bet_centrality = nx.betweenness_centrality(G, normalized = True, endpoints = False, weight= None)
        #Finding closeness centrality
        close_centrality = nx.closeness_centrality(G)
        #finding clustering coefficient
        clustering_coeff = nx.clustering(G, nodes=None, weight= None)

    #finding nodes
    deg_list = defaultdict(list)
    node_list = list(G.nodes)
    for i in node_list:
        #print(i)
        if weighted == "YES":
            #find neighbor and sum edge weight
            fn = list(G.neighbors(i)) #getting neighbours
            edge_w = []
            for n in fn:
                w = G[i][n]["weight"]
                w = 1/w
                edge_w.append(w)
                deg = sum(edge_w) #for weighted
        else:
            deg = G.degree[i] #for unweighted
        deg_list[i].append(deg)
    
    sorted_deg = dict(sorted(deg_list.items(), key=lambda x: x[1], reverse = True)) #sorting 
    n = round(len(sorted_deg) * percent) #finding the number of top nodes
  
    #writing the centrality measures to a file for hubs
    merge_measures = defaultdict(list) #setting the value corresponding to the key to store a list
    key = list(sorted_deg.keys())[:n] #selecting hubs on the basis of the top percentages
    #print(key)
    with open("hub_first_neighbour.txt", 'a') as f: #opening file to append first neighbour and edge weight for each hubs
        f.write('Hub,First_neighbors,Edge_weight\n')
        for i in key:
            if weighted == "YES":
                #find neighbor and sum edge weight
                fn = list(G.neighbors(i)) #getting neighbours
                edge_w = []
                for n in fn:
                    w = G[i][n]["weight"]
                    w = 1/w
                    edge_w.append(w)
                    f.write('%s,%s,%f\n' %(i,n,w)) #writing to the file
                deg = sum(edge_w) #for weighted
            else:
                deg = G.degree[i] #for unweighted
            data = [clustering_coeff[i],deg_centrality[i], deg , close_centrality[i],bet_centrality[i]] #making a list to append
            merge_measures[i].append(data)
    with open("centrality_measures_hub.txt", 'w') as f: 
        f.write('Hub\tclustering_coefficient\tdegree_centrality\tdegree\tcloseness_centrality\tbetweenness_centrality\n')
        for key, value in merge_measures.items():
            f.write((('%s,%s\n' % (key, ('%s'%(value)).strip("[]"))).replace(',','\t')).replace('[','')) #clearing the list and making it tab seperated
        

#getting arguments and calling the function
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Provide a parameter file")
        sys.exit(1)
    par_file = sys.argv[1]
    find_hub(par_file)