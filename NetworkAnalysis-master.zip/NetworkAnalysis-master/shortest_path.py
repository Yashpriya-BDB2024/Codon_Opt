#import
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx
import math


#function for finding shortest path
def find_shortest_path(par_file):
    #extracting the parameters
    with open(par_file, 'r') as f:
        lines = f.readlines()
    if len(lines) != 3:
        print("Give three input")
        return
    graph = lines[0].strip()
    target = lines[1].strip()
    weighted = lines[2].strip()
    
    #Constructing a network
    edge = pd.read_csv(graph,sep='\t')
    if weighted == "YES":
        #inverse the weight - for correct representation of signal
        a = edge['weight']
        a = 1/a
        edge['weight'] = a
    
    #creating a network with the edge list file
    G = nx.from_pandas_edgelist(edge, source='source', target='target', edge_attr=True)
    #ploting the network
    nx.draw_networkx(G, pos=nx.circular_layout(G), with_labels=True, font_weight='bold') 
    edge_weight = nx.get_edge_attributes(G,'weight')
    nx.draw_networkx_edge_labels(G, pos=nx.circular_layout(G), edge_labels = edge_weight)
    
    #file format as (tsv)
    #source target
    df = pd.read_csv(target,sep='\t')
    #finding shortest path
    with open("shortest_path.txt", 'w') as f: 
        f.write('Source\tTarget\tShortest_path\tNormalized_distance\n')
        for index, row in df.iterrows():
            s = row['source']
            t = row['target']
            if weighted == "NO":
                shortest_path = nx.shortest_path(G, s, t)
                length = nx.shortest_path_length(G, s, t)
            else:
                shortest_path = nx.dijkstra_path(G, s, t)
                length = nx.shortest_path_length(G, s, t, weight='weight')
            dist = np.log10(length) + 1
            f.write('%s\t%s\t%s\t%f\n'%(s,t,shortest_path,dist))

#getting arguments and calling the function
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Provide a parameter file")
        sys.exit(1)
    par_file = sys.argv[1]
    find_shortest_path(par_file)
