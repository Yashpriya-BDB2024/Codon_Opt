import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns
from PyWGCNA import WGCNA
from scipy.spatial.distance import squareform
from scipy.cluster.hierarchy import linkage, dendrogram, leaves_list
import gseapy as gp
import openpyxl
from collections import defaultdict
import mygene
import os
import sys
import networkx as nx
from functools import reduce

os.mkdir("./WGCNA_Pipeline_results")
count_matrix= pd.read_csv("../Bulk_RNA_pipeline/Sample/DGE_Analysis/Significant_DGE_count_matrix.csv")
Normalised_matrix = pd.read_excel("./normalized_counts_edgeR_TMM.xlsx")
count_matrix_new= count_matrix[['Geneid','symbol']]
final_matrix= pd.merge(count_matrix_new,Normalised_matrix)
final_matrix= final_matrix.loc[:, final_matrix.columns != 'Geneid']
final_matrix=final_matrix.rename(columns = {'symbol':''})
final_matrix= final_matrix.set_index("")
final_matrix=final_matrix.T
final_matrix.index.names = ['Sample_id']

#### Filtering genes using WGCNA in-built function
gsg=WGCNA.goodSamplesGenes(final_matrix,minFraction=0.5, minNSamples=4, minNGenes=4)

goodSamples = gsg[0]  # First array corresponds to samples
goodGenes = gsg[1]    # Second array corresponds to genes

# Filter out bad samples and genes
matrix = final_matrix.loc[goodSamples, goodGenes]

scaler = StandardScaler()
scaled_data = scaler.fit_transform(final_matrix.T) 
# Step 2: Calculate the mean of the scaled data across samples
mean_scaled = np.mean(scaled_data, axis=1)

# Step 3: Calculate the distance of each gene from the mean
distances = np.linalg.norm(scaled_data - mean_scaled[:, np.newaxis], axis=1)

# Step 4: Calculate the threshold (mean of distances + 3 * standard deviation of distances)
threshold = np.mean(distances) + 3 * np.std(distances)
print(f"Outlier threshold: {threshold}")
non_outliers = distances <= threshold
filtered_tpm_df = final_matrix.loc[:, non_outliers]

# Output the filtered data shape
print(f"Data shape before filtering: {final_matrix.shape}")
print(f"Data shape after filtering: {filtered_tpm_df.shape}")

# Create a DataFrame for plotting
distance_df = pd.DataFrame({'Genes': final_matrix.columns, 'Distance': distances, 'Outlier': distances > threshold})

# Plot the distances
plt.figure(figsize=(10, 6))

# Create the scatter plot
sns.scatterplot(data=distance_df, x='Genes', y='Distance', hue='Outlier', palette={True: 'red', False: 'blue'})

# Add the threshold line
plt.axhline(y=threshold, color='green', linestyle='--', label=f'Threshold = {threshold:.2f}')

# Set the title and labels
plt.title('Gene Distance from Mean and Outlier Detection')
plt.xticks([])  # Remove x-axis labels
plt.ylabel('Distance from Mean')

# Annotate the outlier genes
for index, row in distance_df[distance_df['Outlier']].iterrows():
    plt.text(row['Genes'], row['Distance'], row['Genes'], fontsize=8, ha='right', color='black')

plt.legend()
plt.tight_layout()

# Show/save the plot
# plt.show()
plt.savefig("./WGCNA_Pipeline_results/Outlier_detection_plot",bbox_inches="tight")
plt.close()

outliers=list(distance_df[distance_df['Outlier']]['Genes'])
print("outliers-",outliers)

filtered_tpm_df = final_matrix.drop(outliers,axis=1)

##### Pick soft threshold power #####
soft_threshold_result=WGCNA.pickSoftThreshold(filtered_tpm_df,RsquaredCut=0.85)
soft_threshold_matrix= soft_threshold_result[1]
plt.figure(figsize=(10, 6))
plt.plot(soft_threshold_matrix['Power'], soft_threshold_matrix['SFT.R.sq'], label='Scale-Free Topology Fit (R^2)', color='blue', lw=2, marker= 'o')
plt.title('Soft-Threshold Power Selection')
plt.xlabel('Soft-Threshold Power')
plt.ylabel('Scale-Free Topology Fit (R^2)')
plt.axhline(y=0.85, linestyle='--', color='red', label='R^2 = 0.85')  # Optional: reference line
plt.legend(loc='lower right')
plt.grid()
# plt.show()
plt.savefig("./WGCNA_Pipeline_results/Soft_threshold_plot",bbox_inches="tight")
plt.close()


### mean connectivity plot ####
plt.plot(soft_threshold_matrix['Power'], soft_threshold_matrix['mean(k)'], label='Mean connectivity', color='skyblue', lw=2, marker= 'o')
plt.title('Mean Connectivity')
plt.xlabel('Soft-Threshold Power')
plt.ylabel('Mean Connectivity')
plt.grid()
# plt.show()
plt.savefig("./WGCNA_Pipeline_results/Mean_connectivity_plot",bbox_inches="tight")
plt.close()

#### selecting best soft threshold power
soft_threshold_power=soft_threshold_result[0]
print("soft_threshold_power ->",soft_threshold_power)

adjacency_matrix = WGCNA.adjacency(filtered_tpm_df,adjacencyType='unsigned', power=soft_threshold_power)
# print(adjacency_matrix)

WGCNA.checkAdjMat(adjacency_matrix)

### tom Matrix ###
TOMsimilarity_matrix=WGCNA.TOMsimilarity(adjacency_matrix,TOMType='unsigned')
dissTOM= 1-TOMsimilarity_matrix

### H-clustering using scipy Linkage #####
dissTOM = dissTOM.round(5)
disTOM_condensed = squareform(dissTOM)
geneTree = linkage(disTOM_condensed, method='average')

dynamic_tree_cut = WGCNA.cutreeHybrid(dendro= np.array(geneTree),distM=dissTOM,minClusterSize=30, deepSplit=2,pamRespectsDendro= False)
# print(dynamic_tree_cut)
custom_colors = [
    "lightgreen",
    "skyblue",
    "Pink",
    "Yellow",
    "red",
    "darkorange",
    "blue",
    "blueviolet",
    "Orange",
    "Chartreuse",
    "deeppink",
    "Gold",
    "limegreen",
    "orangered",
    "Steelblue",
    "Plum",
    "Greenyellow",
    "Tomato",
    "violet",
    "cyan",
    "coral",
    "Hotpink","peru","tomato","olivedrab"
]
dynamicColors = WGCNA.labels2colors(dynamic_tree_cut,colorSeq=custom_colors)
# print(dynamicColors)

eigen_genes=WGCNA.moduleEigengenes(filtered_tpm_df,dynamicColors)

#### saving matrix files ####
adjacency_df=pd.DataFrame(adjacency_matrix,columns=filtered_tpm_df.columns,index=filtered_tpm_df.columns)
adjacency_df.to_csv("./WGCNA_Pipeline_results/adjacency_Dataframe.csv")
TOMsimilarity_matrix.index= filtered_tpm_df.columns
TOMsimilarity_matrix.columns =filtered_tpm_df.columns
TOMsimilarity_matrix.to_csv("./WGCNA_Pipeline_results/Tom_similarity_matrix.csv")
### saving Modules gene file
Module_df= pd.DataFrame(filtered_tpm_df.columns)
Module_df['ModuleColor'] = dynamicColors
Module_df.columns=['symbol','ModuleColor']
Module_df.set_index('symbol', inplace=True)
Module_df.to_csv("./WGCNA_Pipeline_results/Module_genes_info.csv")

print(Module_df['ModuleColor'].value_counts())


##### Visualizations #####
plt.figure(figsize=(10, 7))
dendrogram(geneTree)
plt.title("Hierarchical Clustering Dendrogram")
plt.xlabel("Gene")
plt.ylabel("Distance")
# plt.show()
plt.savefig("./WGCNA_Pipeline_results/Genes_dendogram_plot",bbox_inches="tight")
plt.close()

sns.histplot(Module_df, x= 'ModuleColor',hue = 'ModuleColor')
plt.savefig("./WGCNA_Pipeline_results/Module_genes_count_plot",bbox_inches="tight")
plt.close()

### Module dendogram ####
MEdiss= 1- eigen_genes['eigengenes'].corr()
MEtree= linkage(squareform(MEdiss), method='average')
# Plotting the dendrogram
plt.figure(figsize=(10, 6))
dendrogram(MEtree, leaf_rotation=90, labels=MEdiss.columns)

plt.title('Dendrogram of Modules')
plt.xlabel('Modules')
plt.ylabel('Distance')

plt.savefig("./WGCNA_Pipeline_results/Module_Dendrogram",bbox_inches="tight")
plt.close()

#### TOM PLOT ###
dissTOM.index= filtered_tpm_df.columns
dissTOM.columns =filtered_tpm_df.columns
# Extract the module colors for rows and columns using the index from the TOMsimilarity_matrix
row_colors = [Module_df.loc[gene, 'ModuleColor'] for gene in dissTOM.index]
col_colors = [Module_df.loc[gene, 'ModuleColor'] for gene in dissTOM.columns]

# Generate the clustermap with module color annotations
g = sns.clustermap(dissTOM, 
                   cmap='Reds',metric="correlation",
                   row_cluster=True,  # Enable row dendrogram
                   col_cluster=True,  # Enable column dendrogram
                   figsize=(12, 12),  # Adjust the figure size
                   cbar_kws={'label': 'TOM Similarity'},  # Color bar label
                   method='average',  # Clustering method
                   row_colors= row_colors,
                   col_colors=col_colors,
                  row_linkage=geneTree,col_linkage=geneTree) 

plt.title("TOM Similarity Matrix", fontsize=16)

# Show plot
plt.savefig("./WGCNA_Pipeline_results/TOM_Plot",bbox_inches="tight")
plt.close()

########### Enrichment Analysis ##########
Module_genes= Module_df.reset_index()
dge_list= pd.read_csv("/bioinfo/software/Bulk_RNA_pipeline/Sample/DGE_Analysis/Significant_DGE_list.csv")
dge_list = dge_list[['symbol','log2FoldChange']]
Module_dge_df= pd.merge(Module_genes,dge_list)

for each in Module_dge_df['ModuleColor'].unique():
    print("GSEA started for Module : "+ each)
    dge_module = Module_dge_df[Module_dge_df['ModuleColor']== each]
    dem2_1 = dge_module[['symbol','log2FoldChange']]
    dem2_1=dem2_1.sort_values(by='log2FoldChange', ascending=False).reset_index(drop=True)
    try:
        gsea_res = gp.prerank(rnk=dem2_1, 
                          gene_sets='GO_Biological_Process_2023', 
                          organism='Human',   
                          threads=4,
                          min_size=5,
                          max_size=1000,
                          permutation_num=1000,  
                          outdir=None,           
                          seed=6,                
                          verbose=True)
        results = gsea_res.res2d
        results.to_csv("./WGCNA_Pipeline_results/GO_Biological_Process_"+each+"_Module.csv")
        print(f'*****GO-BIOLOGICAL PATHWAY COMPLETED FOR MODULE_{each}******')
    except Exception as e:
        print(f"Error in GO Biological Process for Module_{each}: {e}")
    try:
        gsea_res = gp.prerank(rnk=dem2_1, 
                          gene_sets='GO_Molecular_Function_2023', 
                          organism='Human',   
                          threads=4,
                          min_size=5,
                          max_size=1000,
                          permutation_num=1000,  
                          outdir=None,           
                          seed=6,                
                          verbose=True)
        results = gsea_res.res2d
        results.to_csv("./WGCNA_Pipeline_results/GO_Molecular_Function_"+each+"_Module.csv")
        print(f'*****GO-MOLECULAR FUNCTION COMPLETED FOR MODULE_{each}******')
    except Exception as e:
        print(f"Error in GO Molecular Function for Module_{each}: {e}")
        
########### Network scores ############
print("***** Calculating network score ******")
G = nx.from_pandas_adjacency(adjacency_df)
# Get number of edges
num_edges = G.number_of_edges()
print("edges-->",num_edges)
# Get number of nodes
num_nodes = G.number_of_nodes()
print("nodes-->", num_nodes)

##degree calculation
degree = nx.degree(G,weight='weight')
degree = dict(degree)
degree_df= pd.DataFrame(list(degree.items()), columns=['symbol', 'Degree'])
## betweeness centrality
bet_centrality = nx.betweenness_centrality(G, normalized = True, endpoints = False, weight='weight')
bet_centrality_df= pd.DataFrame(list(bet_centrality.items()), columns=['symbol', 'bet_centrality'])
## closeness centrality
close_centrality = nx.closeness_centrality(G, distance = 'weight')
close_centrality_df= pd.DataFrame(list(close_centrality.items()),columns=['symbol','Close_centrality'])
## clustering coeff
clustering_coeff = nx.clustering(G, nodes=None, weight='weight')
clustering_coeff_df= pd.DataFrame(list(clustering_coeff.items()),columns=['symbol','clustering_coeff'])

network_data_frames = [bet_centrality_df,close_centrality_df,clustering_coeff_df,degree_df]
network_df_merged = reduce(lambda  left,right: pd.merge(left,right,on=['symbol'],
                                            how='outer'), network_data_frames)

final_scoring_df = pd.merge(network_df_merged,Module_dge_df)

final_scoring_df.to_csv("./Network_scores.csv",index= False)